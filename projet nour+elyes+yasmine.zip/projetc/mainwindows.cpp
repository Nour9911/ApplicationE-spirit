#include "mainwindows.h"
#include "ui_mainwindows.h"

MainWindows::MainWindows(QWidget *parent)


{

}

MainWindows::~MainWindows()
{

}
