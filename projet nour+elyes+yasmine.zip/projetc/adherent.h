#ifndef ADHERENT_H
#define ADHERENT_H

#include <QDialog>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include "gestion_adh.h"
#include "gestion_cad.h"
#include "smtp.h"
#include <QtWidgets/QMessageBox>

namespace Ui {
class adherent;
}

class adherent : public QDialog
{
    Q_OBJECT

public:
    explicit adherent(QWidget *parent = nullptr);
    ~adherent();

private slots:
    void on_Ajouter_adherent_2_clicked();

    void on_supprimer_adherent_3_clicked();

    void on_Ajouter_cadeau_2_clicked();

    void on_supprimer_cadeau_2_clicked();

    void on_chercher_modif_adherent_clicked();

    void on_modifier_adherent_clicked();

    void on_modifier_cadeau_clicked();

    void on_chercher_cadeau_clicked();

    void on_tri_asc_clicked();

    void on_tri_desc_clicked();

    void on_tri_asc_cad_clicked();

    void on_tri_desc_cad_clicked();

    void on_affecter_cadeau_adh_clicked();

    void on_recherche_cadeau_id_textChanged(const QString &arg1);

    void on_chercher_adherent_textChanged(const QString &arg1);

    void sendMail();

    void mailSent(QString);



private:
    Ui::adherent *ui;
    gestion_adh tmpadherent;
    gestion_cad tmpcadeau;



};

#endif // ADHERENT_H
