/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGroupBox *groupBox;
    QTabWidget *tabWidget_3;
    QWidget *tab_4;
    QLabel *label_4;
    QLineEdit *lineEdit_username;
    QPushButton *pushButton_login;
    QLabel *label_8;
    QLineEdit *lineEdit_password;
    QLabel *label_45;
    QWidget *tab_5;
    QLabel *label_39;
    QPushButton *pdfp;
    QRadioButton *radioButton_5p;
    QRadioButton *radioButton_6p;
    QPushButton *pushButton_statistique;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(938, 429);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(-2, -10, 951, 651));
        tabWidget_3 = new QTabWidget(groupBox);
        tabWidget_3->setObjectName(QStringLiteral("tabWidget_3"));
        tabWidget_3->setGeometry(QRect(0, 10, 791, 379));
        QFont font;
        font.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font.setPointSize(10);
        font.setBold(false);
        font.setWeight(50);
        tabWidget_3->setFont(font);
        tabWidget_3->setAutoFillBackground(false);
        tabWidget_3->setStyleSheet(QStringLiteral(""));
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        label_4 = new QLabel(tab_4);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(40, 80, 181, 31));
        QFont font1;
        font1.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font1.setPointSize(16);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(50);
        label_4->setFont(font1);
        label_4->setStyleSheet(QLatin1String("font: 16pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_4->setTextFormat(Qt::AutoText);
        lineEdit_username = new QLineEdit(tab_4);
        lineEdit_username->setObjectName(QStringLiteral("lineEdit_username"));
        lineEdit_username->setGeometry(QRect(310, 80, 241, 31));
        lineEdit_username->setStyleSheet(QLatin1String("\n"
"                                         \n"
"background-color: rgb(208, 0, 0);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        lineEdit_username->setClearButtonEnabled(true);
        pushButton_login = new QPushButton(tab_4);
        pushButton_login->setObjectName(QStringLiteral("pushButton_login"));
        pushButton_login->setGeometry(QRect(90, 260, 481, 41));
        pushButton_login->setStyleSheet(QLatin1String("font: 75 10pt \"Perpetua Titling MT\";\n"
"border-bottom-color: rgb(182, 0, 0);\n"
"selection-background-color: rgb(195, 0, 0);"));
        QIcon icon;
        QString iconThemeName = QStringLiteral("ok");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon = QIcon::fromTheme(iconThemeName);
        } else {
            icon.addFile(QStringLiteral("../../Desktop/EMPLOYE_ (1)/EMPLOYE_"), QSize(), QIcon::Normal, QIcon::Off);
        }
        pushButton_login->setIcon(icon);
        pushButton_login->setAutoDefault(true);
        pushButton_login->setFlat(false);
        label_8 = new QLabel(tab_4);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(60, 160, 221, 41));
        label_8->setFont(font1);
        label_8->setStyleSheet(QLatin1String("font: 16pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_8->setTextFormat(Qt::AutoText);
        lineEdit_password = new QLineEdit(tab_4);
        lineEdit_password->setObjectName(QStringLiteral("lineEdit_password"));
        lineEdit_password->setGeometry(QRect(310, 160, 241, 31));
        lineEdit_password->setAutoFillBackground(false);
        lineEdit_password->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(199, 0, 0);\n"
"                                         \n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;\n"
""));
        lineEdit_password->setEchoMode(QLineEdit::Password);
        lineEdit_password->setClearButtonEnabled(true);
        label_45 = new QLabel(tab_4);
        label_45->setObjectName(QStringLiteral("label_45"));
        label_45->setGeometry(QRect(0, 0, 1371, 631));
        label_45->setStyleSheet(QLatin1String("\n"
"background-color: rgb(0, 0, 0);"));
        tabWidget_3->addTab(tab_4, QString());
        label_45->raise();
        label_4->raise();
        lineEdit_username->raise();
        pushButton_login->raise();
        label_8->raise();
        lineEdit_password->raise();
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        label_39 = new QLabel(tab_5);
        label_39->setObjectName(QStringLiteral("label_39"));
        label_39->setGeometry(QRect(0, 0, 871, 451));
        label_39->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        pdfp = new QPushButton(tab_5);
        pdfp->setObjectName(QStringLiteral("pdfp"));
        pdfp->setGeometry(QRect(250, 410, 75, 23));
        radioButton_5p = new QRadioButton(tab_5);
        radioButton_5p->setObjectName(QStringLiteral("radioButton_5p"));
        radioButton_5p->setGeometry(QRect(390, 400, 91, 41));
        radioButton_6p = new QRadioButton(tab_5);
        radioButton_6p->setObjectName(QStringLiteral("radioButton_6p"));
        radioButton_6p->setGeometry(QRect(500, 410, 111, 20));
        pushButton_statistique = new QPushButton(tab_5);
        pushButton_statistique->setObjectName(QStringLiteral("pushButton_statistique"));
        pushButton_statistique->setGeometry(QRect(280, 130, 221, 41));
        pushButton_statistique->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        tabWidget_3->addTab(tab_5, QString());
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 938, 21));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        tabWidget_3->setCurrentIndex(0);
        pushButton_login->setDefault(false);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        groupBox->setTitle(QApplication::translate("MainWindow", "Connexion", nullptr));
#ifndef QT_NO_TOOLTIP
        label_4->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Username</span></p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        label_4->setText(QApplication::translate("MainWindow", "Nom d'utilisateur :", nullptr));
        pushButton_login->setText(QApplication::translate("MainWindow", "Se connecter", nullptr));
#ifndef QT_NO_TOOLTIP
        label_8->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Username</span></p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        label_8->setText(QApplication::translate("MainWindow", "Mot de passe :", nullptr));
        label_45->setText(QString());
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_4), QApplication::translate("MainWindow", "se connecte", nullptr));
        label_39->setText(QString());
        pdfp->setText(QApplication::translate("MainWindow", "Imprimer", nullptr));
        radioButton_5p->setText(QApplication::translate("MainWindow", "croissant", nullptr));
        radioButton_6p->setText(QApplication::translate("MainWindow", "decroissant", nullptr));
        pushButton_statistique->setText(QApplication::translate("MainWindow", "les statistiques des sponsor et pub", nullptr));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_5), QApplication::translate("MainWindow", " tb des statistique", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
