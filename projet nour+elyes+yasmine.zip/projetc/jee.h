#ifndef JEE_H
#define JEE_H
#include "classentraineur.h"
#include "classequipe.h"
#include "classjoueur.h"
#include <QDialog>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include "smtp.h"
#include <QtWidgets/QMessageBox>

namespace Ui {
class jee;
}

class jee : public QDialog
{
    Q_OBJECT

public:
    explicit jee(QWidget *parent = nullptr);
    ~jee();

private slots:
    void on_Ajouter_joueur_clicked();

    void on_supprimer_joueur_clicked();

    void on_chercher_modif_joueur_clicked();

    void on_modifier_joueur_clicked();

    void on_tri_asc_clicked();

    void on_tri_desc_clicked();

    void on_tri_asc_2_clicked();

    void on_tri_desc_2_clicked();

    void on_Ajouter_equipe_clicked();

    void on_supprimer_equipe_clicked();

    void on_chercher_modif_equipe_clicked();

    void on_modifier_equipe_clicked();

     void on_Ajouter_entraineur_clicked();

    void on_supprimer_entraineur_clicked();

    void on_chercher_modif_entraineur_clicked();

    void on_tri_asce_clicked();

    void on_tri_desce_clicked();

    void on_tri_asce_2_clicked();

    void on_tri_desce_2_clicked();

    void on_tri_ascen_clicked();

    void on_tri_descen_clicked();

    void on_tri_ascen_2_clicked();

    void on_tri_descen_2_clicked();

    void on_modifier_entraineur_clicked();

    void on_affecter_en_eq_clicked();

    void on_affecter_j_eq_clicked();

    void on_chercher_joueur_textChanged(const QString &arg1);

    void on_chercher_entraineur_textChanged(const QString &arg1);

    void on_chercher_equipe_textChanged(const QString &arg1);

    void sendMail();

    void mailSent(QString);


private:
    Ui::jee *ui;
    classJoueur tmpjoueur;
    classEquipe tmpequipe;
    classEntraineur tmpentraineur;
};

#endif // JEE_H
