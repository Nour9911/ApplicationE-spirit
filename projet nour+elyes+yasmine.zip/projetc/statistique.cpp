#include "statistique.h"
#include <QPainter>
#include <QSqlQuery>
#include <QVariant>
#include <QColor>


statistique::statistique(QWidget *parent) : QWidget(parent)
{

}

void statistique::paintEvent(QPaintEvent *)
{
    QSqlQuery query;
    query.prepare("SELECT  count(id_cadeau) FROM  cadeau");
    query.exec();
        int c;
            while(query.next())
            {

                  c = query.value(0).toInt();//Récupère le résultat de la requête


            }

             query.prepare("SELECT  count(id_cadeau)  FROM  cadeau where id_adh is NULL ");
            query.exec();
                int c1;
                    while(query.next())
                    {

                          c1 = query.value(0).toInt();//Récupère le résultat de la requête


                    }



    double h = (double) c1 / (double) c * 360;
    QPainter painter(this);
    QRectF size = QRectF(5,5, this->width()-10, this->width()-10);
    painter.setBrush(Qt::green);
    painter.drawPie(size, 0, h*16);
    painter.setBrush(Qt::blue);
    painter.drawPie(size,h*16,(360-h)*16);

}
