#ifndef CLASSSPONS_H
#define CLASSSPONS_H
#include <QString>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QDate>
class classspons
{
public:
    classspons();
    classspons(int,QString,int,QString);
      QString get_nom_spnsor();
      int get_id_s();
      QString get_dates();
      int get_dons();
      bool ajouter();
      bool existeAdmin();

              bool update(int, QString, int,QString);
      //bool modification(int,QString,int);
              QSqlQueryModel * afficher();
              QSqlQueryModel * afficher2(QString);
              bool supprimer(int);
                      void chercher();
                      void search();
                      QSqlQueryModel * afficher_tri_ID();
                      QSqlQueryModel * afficher_tri_ID_DESC();

                      QSqlQueryModel * stat();
                      QSqlQueryModel * stat1();
                      QSqlQueryModel * stat2();
                      QSqlQueryModel * stat3();
                      QSqlQueryModel * stat4();
                      QSqlQueryModel * stat5();
                      QSqlQueryModel * stat6();
                      QSqlQueryModel * stat7();
                      QSqlQueryModel * stat8();
                      QSqlQueryModel * stat9();
                      QSqlQueryModel * stat10();
                      QSqlQueryModel * afficher_dyna_spon(QString sd);

private:
   QString nom_spnsor , dates;
   int  id_s,dons;


};

#endif // CLASSSPONS_H
