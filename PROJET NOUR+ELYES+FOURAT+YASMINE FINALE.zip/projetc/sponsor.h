#ifndef SPONSOR_H
#define SPONSOR_H
#include <classpub.h>
#include <QDialog>
#include <classspons.h>
#include <QDate>
#include <classrev.h>
#include <QApplication>
#include "smtp.h"
#include <QtWidgets/QMessageBox>


namespace Ui {
class sponsor;
}

class sponsor : public QDialog
{
    Q_OBJECT

public:
    explicit sponsor(QWidget *parent = nullptr);
    ~sponsor();

private slots:
        void on_pb_ajouter_clicked();
        void on_pb_supprimer_clicked();
        void on_update_clicked();
        void on_search_clicked();
         void on_pdf_clicked();
        void on_radioButton_5_clicked();
        void on_radioButton_6_clicked();
        void on_voir_3_clicked();


             void on_pb_ajouterp_clicked();
             void on_pb_supprimerp_clicked();
             void on_updatep_clicked();
             void on_searchp_clicked();
             void on_pdfp_clicked();
             void on_radioButton_5p_clicked();
             void on_radioButton_6p_clicked();

             void on_voir_2_clicked();

             void on_ajouterr_clicked();
             void on_ajouterrr_clicked();
             void on_searchr_clicked();
             void on_voir_clicked();
             void on_pdfr_clicked();
             void on_radioButton_5r_clicked();
             void on_radioButton_6r_clicked();




  void sendMail();

  void mailSent(QString);



  void on_lineEdit_nom_spnsor_22_textChanged(const QString &arg1);

  void on_lineEdit_cin_2_textChanged(const QString &arg1);

  void on_lineEdit_cin_3_textChanged(const QString &arg1);

private:
    Ui::sponsor *ui;
    classspons tmpSPON;
    classpub tmppub;
    classrev tmprev;

};

#endif // SPONSOR_H
