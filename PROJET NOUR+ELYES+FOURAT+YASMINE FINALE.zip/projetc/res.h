#ifndef RES_H
#define RES_H
#include <QDialog>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include "reservation.h"
#include "ticket.h"
#include "smtp.h"
#include <QtWidgets/QMessageBox>

namespace Ui {
class res;
}

class res : public QDialog
{
    Q_OBJECT

public:
    explicit res(QWidget *parent = nullptr);
    ~res();

private slots:

    void on_ajouter_res_clicked();

    void on_supprimer_res_clicked();

    void on_chercher_modif_res_clicked();

    void on_modifier_res_clicked();

    void on_tri_asc_res_clicked();

    void on_tri_desc_res_clicked();

    void on_ajouter_ticket_clicked();

    void on_supprimer_ticket_clicked();

    void on_chercher_modif_ticket_clicked();

    void on_modifier_ticket_clicked();

    void on_tri_asc_ticket_clicked();

    void on_tri_desc_ticket_clicked();

    void on_pushButton_clicked();

    void on_chercher_res_2_textChanged(const QString &arg1);

    void on_chercher_res_textChanged(const QString &arg1);

    void sendMail();

    void mailSent(QString);


private:
    Ui::res *ui;
    reservation tmpreservation;
    ticket tmpticket;
};

#endif // RES_H
