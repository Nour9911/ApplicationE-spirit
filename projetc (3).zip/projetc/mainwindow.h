#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <sponsor.h>
#include <QMessageBox>
#include <QDebug>
#include <classspons.h>
#include "login.h"
#include "adherent.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void on_pushButton_login_clicked();

     void on_pushButton_statistique_clicked();

     void on_stat_adherent_clicked();

private:
    Ui::MainWindow *ui;
    adherent *adherent;
};

#endif // MAINWINDOW_H
