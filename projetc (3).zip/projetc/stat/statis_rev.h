#ifndef STATIS_REV_H
#define STATIS_REV_H

#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QVector>
#include <iterator>
#include <classrev.h>
class statis_rev
{
     QVector<classrev>Tab_Stat;
public:
    statis_rev();
    QVector<classrev> :: iterator Chercher_Tab_Stat(int);
        bool Ajouter_Tab_Stat(classrev);
        bool Supprimer_Tab_Stat(int);
        float Calculer_Tab_Stat(QString);
};



#endif // STATIS_REV_H
