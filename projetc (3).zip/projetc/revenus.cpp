#include "classrev.h"

revenus::revenus()
{

}
