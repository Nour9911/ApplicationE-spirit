#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "sponsor.h"
#include "classspons.h"
#include "adherent.h"
#include "connexion.h"
#include <QApplication>
#include "ui_sponsor.h"
#include <QMessageBox>
#include "jee.h"
#include <QPixmap>

//include statistique
#include <QtWidgets/QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QHorizontalStackedBarSeries>
#include <QtCharts/QLineSeries>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowIcon(QIcon("../projetc/e-spirit.png"));
     this->setWindowTitle("LOGIN");
    QPixmap pix(":/new/prefix1/img/e-sport.jpg");

    int w= ui->image_bk->width();
    int h= ui->image_bk->height();
     ui->image_bk->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));


}

MainWindow::~MainWindow()
{
    delete ui;

}


void MainWindow::on_pushButton_login_clicked()
{
    login S;
    //int poste;
        QString username = ui->lineEdit_username->text();
        QString password = ui ->lineEdit_password->text();

       // if (S.verifierCompte(ui->lineEdit_username->text(),ui ->lineEdit_password->text())==2||S.verifierCompte(ui->lineEdit_username->text(),ui ->lineEdit_password->text())==1)
        if (S.verifierCompte(ui->lineEdit_username->text(),ui ->lineEdit_password->text())==1)
        {


                    ui->lineEdit_password->clear();
                    ui->lineEdit_username->clear();

                 if (username=="yasmine") {
                    QMessageBox::information(this, "login","Agent de sponsor");
                       class sponsor r;
                    r.setModal(true);
                    r.exec();
                    }

                 else if (username=="nour") {
                 QMessageBox::information(this,"login","Agent des adhérents");
                 class adherent a;
                 a.setModal(true);
                 a.exec();
                }

                 else if (username=="elyes") {
                 QMessageBox::information(this,"login","Agent de match ");
                 class jee j;
                 j.setModal(true);
                 j.exec();
                }

                 else if (username=="fourat") {
                  QMessageBox::information(this,"login","Agent de reservation ");
                  //class adherent a;
                  //a.setModal(true);
                  //a.exec();
                 }

                  else if (username=="louay") {
                  QMessageBox::information(this,"login","Agent de evenement ");
                 // class adherent a;
                  //a.setModal(true);
                  //a.exec();
                 }



        } else {
               QMessageBox::warning(this, "login","username and password are not correct");
            }

        }


void MainWindow::on_pushButton_statistique_clicked() {


    QT_CHARTS_USE_NAMESPACE
             MainWindow w;

            // Assign names to the set of bars used
             QSqlQuery query;

             query.prepare("SELECT  count (DONS) FROM  SPONSOR ");
             query.exec();
                 int s;
                     while(query.next())
                     {

                           s = query.value(0).toInt();//Récupère le résultat de la requête


                     }

                     query.prepare("SELECT  count (ID_PUB) FROM  PUB ");
                     query.exec();
                         int s1;
                             while(query.next())
                             {

                                   s1 = query.value(0).toInt();//Récupère le résultat de la requête


                             }

                     QBarSet *set0 = new QBarSet("sponsor");
                     QBarSet *set1 = new QBarSet("pub");
                    *set0 << 2 << 3 << 5 << 3 << 4 << s ;
                    *set1  << 5 << 4 << 13 << 3 << 6 << s1 ;
                     QBarSeries *series = new QBarSeries();
                     series->append(set0);
                     series->append(set1);
                     QChart *chart = new QChart();

                     // Add the chart
                     chart->addSeries(series);
                     chart->setAnimationOptions(QChart::AllAnimations);

                     // Holds the category titles
                     QStringList categories;

                     categories<< "2015" << "2016" << "2017"  << "2018" << "2019" << "2020" ;

                     // Adds categories to the axes
                     QBarCategoryAxis *axis = new QBarCategoryAxis();
                     axis->append(categories);
                     chart->createDefaultAxes();
                     chart->setAxisX(axis, series);

                     chart->legend()->setAlignment(Qt::AlignBottom);



                     QChartView *chartView = new QChartView(chart);
                     chartView->setRenderHint(QPainter::Antialiasing);

                     // Used to change the palette
                     QPalette pal = qApp->palette();

                     // Change the color around the chart widget and text
                     pal.setColor(QPalette::Window, QRgb(0xff9999));
                     pal.setColor(QPalette::WindowText, QRgb(0x660000));

                     // Apply palette changes to the application
                     qApp->setPalette(pal);

                     // Customize the title font
                         QFont font;
                         font.setPixelSize(40);
                         chart->setTitleFont(font);
                         chart->setTitleBrush(QBrush(Qt::cyan));
                         chart->setTitle("statistique revenus");

                     QMainWindow window;


            setCentralWidget(chartView);


}


void MainWindow::on_stat_adherent_clicked()
{
    QT_CHARTS_USE_NAMESPACE
             MainWindow w;

            // Assign names to the set of bars used
             QSqlQuery query;

    query.prepare("SELECT  count (ID_ADHERENT) FROM  ADHERENT ");
    query.exec();
        int a;
            while(query.next())
            {

                  a = query.value(0).toInt();//Récupère le résultat de la requête


            }

    QBarSet *set0 = new QBarSet("Adhérent ajouté");

   *set0 << 2 << 3 << 5 << 3 << 4 << a ;

    QBarSeries *series = new QBarSeries();
    series->append(set0);

    QChart *chart = new QChart();

    // Add the chart
    chart->addSeries(series);
    chart->setAnimationOptions(QChart::AllAnimations);

    // Holds the category titles
    QStringList categories;

    categories<< "Janvier" << "Février" << "Mars"  << "Mai" << "Juin" << "Juillet" ;

    // Adds categories to the axes
    QBarCategoryAxis *axis = new QBarCategoryAxis();
    axis->append(categories);
    chart->createDefaultAxes();
    chart->setAxisX(axis, series);

    chart->legend()->setAlignment(Qt::AlignBottom);



    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);

    // Used to change the palette
    QPalette pal = qApp->palette();

    // Change the color around the chart widget and text
    pal.setColor(QPalette::Window, QRgb(0xff9999));
    pal.setColor(QPalette::WindowText, QRgb(0x660000));

    // Apply palette changes to the application
    qApp->setPalette(pal);

    // Customize the title font
        QFont font;
        font.setPixelSize(40);
        chart->setTitleFont(font);
        chart->setTitleBrush(QBrush(Qt::cyan));
        chart->setTitle("statistique adhérent");

    QMainWindow window;


setCentralWidget(chartView);
}
