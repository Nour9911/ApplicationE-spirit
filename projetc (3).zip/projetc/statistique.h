#ifndef STATISTIQUE_H
#define STATISTIQUE_H

#include <QSqlQueryModel>

class statistique
{
public:
    statistique();

     QSqlQueryModel * afficher_stat();
};

#endif // STATISTIQUE_H
