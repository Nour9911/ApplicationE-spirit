#include "sponsor.h"
#include "ui_sponsor.h"
#include <QMessageBox>
#include <QPixmap>
#include <QSound>
#include <QTextStream>
#include <QTextDocument>
#include <QDialog>
#include <QPrintDialog>
#include <QPrinter>
#include <QDate>
#include <classpub.h>
#include <classrev.h>
#include <QtCharts>
#include <QLineSeries>
#include <mainwindow.h>
#include <QApplication>
#include <connexion.h>
#include <login.h>
#include <classrev.h>
#include <classrev.h>
#include <QMessageBox>
#include "smtp.h"


#include <QtWidgets/QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QHorizontalStackedBarSeries>
#include <QtCharts/QLineSeries>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <mainwindow.h>


sponsor::sponsor(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::sponsor)
{
    ui->setupUi(this);
    connect(ui->sendBtn_4, SIGNAL(clicked()),this, SLOT(sendMail()));
    connect(ui->exitBtn_4, SIGNAL(clicked()),this, SLOT(close()));
    ui->tabSPON->setModel(tmpSPON.afficher());

 QColor fontBold; fontBold.setBlue(true);

this->setWindowTitle("GESTION DES SPONSORS");
this->setWindowIcon(QIcon("../projetc/e-spirit.png"));
QPixmap pix(":/new/prefix1/img/background.jpg");

 int w= ui->labelB_2->width();
 int h= ui->labelB_2->height();
 int w1= ui->labelB_4->width();
 int h1= ui->labelB_4->height();
 int w2= ui->labelB_5->width();
 int h2= ui->labelB_5->height();
 int w3= ui->labelB_6->width();
 int h3= ui->labelB_6->height();



 ui->labelB_2->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
 ui->labelB_4->setPixmap(pix.scaled(w1,h1,Qt::KeepAspectRatio));
 ui->labelB_5->setPixmap(pix.scaled(w2,h2,Qt::KeepAspectRatio));
 ui->labelB_6->setPixmap(pix.scaled(w3,h3,Qt::KeepAspectRatio));



 QSqlQuery query;
 query.prepare("select ID_SPONSOR  from SPONSOR");
 if(query.exec())
     {
         while(query.next())
         {

 QString s=query.value(0).toString();

             ui->comboBox->addItem(s);

         }
     }

 query.prepare("select ID_PUB  from PUB");
 if(query.exec())
     {
         while(query.next())
         {

 QString s=query.value(0).toString();

             ui->comboBox_2->addItem(s);

         }
     }

}

sponsor::~sponsor()
{
    delete ui;
}


void sponsor::on_pb_ajouter_clicked()
{

    bool verif_id,verif_nom,verif_dons,verif_date;
       verif_id=true;
       verif_nom=true;
       verif_dons=true;
       verif_date=true;

        bool verifnom = false;
        bool verifid = false;
        bool verifdons = false;


    QString numbers = "0123456789";
    QString alphab = "azertyuiopqsdfghjklmwxcvbnéàçAZERTYUIOPQSDFGHJKLMWXCVBN";




   int id_s = ui->lineEdit_id->text().toInt();

                     if(( 1<=id_s) && (id_s <=99999)) {

                         verifid = true;

                     }

                 if(verifid == false ){
                     verif_id = false;
                     QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                 QObject::tr("Erreur id contient seulement des nbr et moin de 99999 .\n"
                                             "Click Cancel to exit."), QMessageBox::Cancel);


                 }


    QString nom_spnsor = ui->lineEdit_nom_spnsor->text();
int v=0;
    for(int i = 0; i < nom_spnsor.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(nom_spnsor[i] == numbers[j]){
 v = v +1; }

  if (v == 0)
                          verifnom = true;
  else if(v != 0)
verifnom = false;

                  }
                  if(verifnom == false ){
                      verif_nom = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur nom contient seulement des alphabets !!  .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }

    int dons = ui->lineEdit_dons->text().toInt();

                      if( 100 <=dons)  {

                          verifdons = true;

                      }

                  if(verifdons == false ){
                      verif_dons = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur dons contient seulement des nbr et sup 100DT .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);


                  }


    QString dates = ui->lineEdit_date->text();



  if((verif_id == true)&&(verif_nom== true) && (verif_dons==true)&&(verif_date==true)){
    classspons S(id_s, nom_spnsor, dons, dates);
  bool test=S.ajouter();
  if(test)
{ui->tabSPON->setModel(tmpSPON.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter un sponsor"),
                  QObject::tr("sponsor ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

  }
  
  ui->comboBox->setModel(tmprev.afficherref());
  ui->comboBox_2->setModel(tmprev.afficherrefp());
  }
  else
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un sponsor"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
}


void sponsor::on_pb_supprimer_clicked()
{

    bool verif_id;
       verif_id=true;


        bool verifid = false;
int id_s = ui->lineEdit_id_s->text().toInt();
if(( 1<=id_s) && (id_s <=99999)) {

    verifid = true;

}

if(verifid == false ){
verif_id = false;
QMessageBox::information(nullptr, QObject::tr("Erreur"),
            QObject::tr("Erreur id contient seulement des nbr et moin de 99999 .\n"
                        "Click Cancel to exit."), QMessageBox::Cancel);


}
if(verif_id == true){
bool test=tmpSPON.supprimer(id_s);
if(test)
{ui->tabSPON->setModel(tmpSPON.afficher());//refresh
    QMessageBox::information(nullptr, QObject::tr("Supprimer un sponsor"),
                QObject::tr("sponsor supprimé.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

    ui->comboBox->setModel(tmprev.afficherref());
    ui->comboBox_2->setModel(tmprev.afficherrefp());
} }
else
    QMessageBox::critical(nullptr, QObject::tr("Supprimer un employé"),
                QObject::tr("Erreur !.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}



void sponsor::on_update_clicked()
{
    bool verif_id,verif_nom,verif_dons,verif_date;
       verif_id=true;
       verif_nom=true;
       verif_dons=true;
       verif_date=true;

        bool verifnom = false;
        bool verifid = false;
        bool verifdons = false;


    QString numbers = "0123456789";
    QString alphab = "azertyuiopqsdfghjklmwxcvbnéàçAZERTYUIOPQSDFGHJKLMWXCVBN";

    int id_s = ui->lineEdit_id_22->text().toInt();
    if(( 1<=id_s) && (id_s <=99999)) {

        verifid = true;

    }

if(verifid == false ){
    verif_id = false;
    QMessageBox::information(nullptr, QObject::tr("Erreur"),
                QObject::tr("Erreur id contient seulement des nbr et moin de 99999 .\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}

    QString nom_spnsor= ui->lineEdit_nom_22->text();
    int v=0;
    for(int i = 0; i < nom_spnsor.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(nom_spnsor[i] == numbers[j]){
  v = 1+v;}
 //b = v +1;

  // if (v == nom_spnsor.length())
  if (v == 0)
                          verifnom = true;
  else if(v != 0)
verifnom = false;

                     

                      }
                  
                  if(verifnom == false ){
                      verif_nom = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur nom contient seulement des alphabets !!  .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }

    int dons = ui->lineEdit_dons_22->text().toInt();
    if( 100 <=dons)  {

        verifdons = true;

    }

if(verifdons == false ){
    verif_dons = false;
    QMessageBox::information(nullptr, QObject::tr("Erreur"),
                QObject::tr("Erreur dons contient seulement des nbr et sup 100DT .\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}
   QString dates = ui->lineEdit_date_22->text();


    if((verif_id == true)&&(verif_nom== true) && (verif_dons==true)&&(verif_date==true)){

        bool test=tmpSPON.update(id_s,nom_spnsor,dons, dates);


    if(test)
    {ui->tabSPON->setModel(tmpSPON.afficher());//refresh

        QMessageBox::information(nullptr, QObject::tr("Modifier un sponsor"),
                    QObject::tr("sponsor modifié.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    } }
    else
      {  QMessageBox::critical(nullptr, QObject::tr("Modifier Un spons"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

}}

/*
void sponsor::on_update_clicked()
{

    classspons  c;
    int id_s = ui->lineEdit_id_22->text().toInt();
    QString nom_spnsor = ui->lineEdit_nom_22->text();
    int dons = ui->lineEdit_dons_22->text().toInt();

    bool test=c.modification(id_s,nom_spnsor,dons);


    if(test)

    {

        ui->tabSPON->setModel(tmpSPON.afficher());//refresh
                QMessageBox::information(nullptr, QObject::tr("Modifier un sponsor"),
                            QObject::tr("sponsor modifié.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
         }

   else
    {
        QMessageBox::critical(nullptr, QObject::tr("Modifier Un spons"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    }

*/

void sponsor::on_search_clicked()
{
    bool verif_id ;
       verif_id=true;


        bool verifid = false;
           QString alphab = "azertyuiopqsdfghjklmwxcvbnéàçAZERTYUIOPQSDFGHJKLMWXCVBN";
    QString numbers = "0123456789";
 QString val = ui->lineEdit_nom_spnsor_22->text();
 int v=0; 
 for(int i = 0; i < val.length(); i++){
               for(int j = 0; j < alphab.length(); j++){
                   if(val[i] == alphab[j]){
 v = 1+v;}
   if (v == 0)
                           verifid = true;
   else if(v != 0)
 verifid = false;



               }
               if(verifid == false ){
                   verif_id = false;
                   QMessageBox::information(nullptr, QObject::tr("Erreur"),
                               QObject::tr("Erreur ecrit seulement des nbr !!  .\n"
                                           "Click Cancel to exit."), QMessageBox::Cancel);

                   break;
               }
           }



if(verif_id == true)
    ui->tabSPON_2->setModel(tmpSPON.afficher2(val));


}


void sponsor::on_pdf_clicked()
{
    QString strStream;
       QTextStream out(&strStream);

       const int rowCount = ui->tabSPON->model()->rowCount();
       const int columnCount = ui->tabSPON->model()->columnCount();
       out <<"<html>\n"
             "<head>\n"
              "<meta Content=\"Text/html; charset=Windows-1251\">\n"
           << "<title>ERP - COMmANDE LIST<title>\n "
           << "</head>\n"
           "<body bgcolor=#ffffff link=#5000A0>\n"

              "<table style=\"text-align: center; font-size: 20px;\" border=1>\n "
             "</br> </br>";
       // headers
       out << "<thead><tr bgcolor=#d6e5ff>";
       for (int column = 0; column < columnCount; column++)
           if (!ui->tabSPON->isColumnHidden(column))
               out << QString("<th>%1</th>").arg(ui->tabSPON->model()->headerData(column, Qt::Horizontal).toString());
       out << "</tr></thead>\n";

       // data table
       for (int row = 0; row < rowCount; row++) {
           out << "<tr>";
           for (int column = 0; column < columnCount; column++) {
               if (!ui->tabSPON->isColumnHidden(column)) {
                   QString data =ui->tabSPON->model()->data(ui->tabSPON->model()->index(row, column)).toString().simplified();
                   out << QString("<td bkcolor=0>%1</td>").arg((!data.isEmpty()) ? data : QString("&nbsp;"));
               }
           }
           out << "</tr>\n";
       }
       out <<  "</table>\n"
           "</body>\n"
           "</html>\n";

       QTextDocument *document = new QTextDocument();
       document->setHtml(strStream);

       QPrinter printer;

       QPrintDialog *dialog = new QPrintDialog(&printer, nullptr);
       if (dialog->exec() == QDialog::Accepted) {
           document->print(&printer);
       }


       delete document;

}


void sponsor::on_radioButton_5_clicked()
{

       ui->tabSPON->setModel(tmpSPON.afficher_tri_ID());
}

void sponsor::on_radioButton_6_clicked()
{

       ui->tabSPON->setModel(tmpSPON.afficher_tri_ID_DESC());
}

 void  sponsor::on_voir_3_clicked()
 {

        ui->tabSPON->setModel(tmpSPON.afficher());
        ui->comboBox->setModel(tmprev.afficherref());
        ui->comboBox_2->setModel(tmprev.afficherrefp());


 }

void sponsor::on_pb_ajouterp_clicked()
{
    bool verif_id,verif_nom,verif_dure,verif_per,verif_prix ;
       verif_id=true;
       verif_nom=true;
       verif_dure=true;
       verif_per=true;
       verif_prix=true;

        bool verifnom = false;
        bool verifid = false;
        bool verifper = false;
 bool verifprix = false;
 bool verifdure = false;
    QString numbers = "0123456789";
    QString alphab = "azertyuiopqsdfghjklmwxcvbnéàçAZERTYUIOPQSDFGHJKLMWXCVBN";

    int id_p = ui->lineEdit_id_p->text().toInt();
    if(( 1<=id_p) && (id_p <=99999)) {

        verifid = true;

    }

if(verifid == false ){
    verif_id = false;
    QMessageBox::information(nullptr, QObject::tr("Erreur"),
                QObject::tr("Erreur id contient seulement des nbr et moin de 99999 .\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}
    QString nom_pub = ui->lineEdit_nom->text();
     int v=0;
    for(int i = 0; i < nom_pub.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(nom_pub[i] == numbers[j]){
  v = 1+v;}
 //b = v +1;



                  if (v == 0)
                                          verifnom = true;
                  else if(v != 0)
                verifnom = false;



                  }
                  if(verifnom == false ){
                      verif_nom = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur nom contient seulement des alphabets !!  .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }

    int duree = ui->lineEdit_duree->text().toInt();
    if(( 1<=duree) && (duree <=200)) {

        verifdure = true;

    }

if(verifdure == false ){
    verif_dure = false;
    QMessageBox::information(nullptr, QObject::tr("Erreur"),
                QObject::tr("Erreur repetition contient seulement des nbr et moin de 200fois/jr .\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}
    QString dated = ui->lineEdit_date_d->text();


     int period = ui->lineEdit_date_f->text().toInt();
     if(( 1<=period) && (period <=360)) {

         verifper = true;

     }

 if(verifper == false ){
     verif_per = false;
     QMessageBox::information(nullptr, QObject::tr("Erreur"),
                 QObject::tr("Erreur periode contient seulement des nbr et moin de 360 jours .\n"
                             "Click Cancel to exit."), QMessageBox::Cancel);
 }
    int prix = ui->lineEdit_prix->text().toInt();
    if(( 10<=prix)) {

        verifprix = true;

    }

if(verifprix == false ){
    verif_prix = false;
    QMessageBox::information(nullptr, QObject::tr("Erreur"),
                QObject::tr("Erreur prix contient seulement des nbr et prix sup de 10DT  .\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);
}

    if((verif_id == true)&&(verif_nom== true) && (verif_dure==true)&&(verif_per==true)&&(verif_prix==true)){
 classpub S(id_p, nom_pub, duree, dated,period,prix);

  bool test=S.ajouterP();
  if(test)
{ui->tabpub->setModel(tmppub.afficherP());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter un pub"),
                  QObject::tr("pub ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

  }
  ui->comboBox->setModel(tmprev.afficherref());
  ui->comboBox_2->setModel(tmprev.afficherrefp());}
  else
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un pub"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
}


void sponsor::on_pb_supprimerp_clicked()
{


    bool verif_id;
       verif_id=true;


        bool verifid = false;
int id_p = ui->lineEdit_id_3->text().toInt();
if(( 1<=id_p) && (id_p <=99999)) {

    verifid = true;

}

if(verifid == false ){
verif_id = false;
QMessageBox::information(nullptr, QObject::tr("Erreur"),
            QObject::tr("Erreur id contient seulement des nbr et moin de 99999 .\n"
                        "Click Cancel to exit."), QMessageBox::Cancel);


}
if(verif_id == true){

bool test=tmppub.supprimerP(id_p);
if(test)
{ui->tabpub->setModel(tmppub.afficherP());//refresh
    QMessageBox::information(nullptr, QObject::tr("Supprimer un pub"),
                QObject::tr("pub supprimé.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);
    ui->comboBox->setModel(tmprev.afficherref());
    ui->comboBox_2->setModel(tmprev.afficherrefp());
} }
else
    QMessageBox::critical(nullptr, QObject::tr("Supprimer un employé"),
                QObject::tr("Erreur !.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}

void sponsor::on_updatep_clicked()
{
    bool verif_id,verif_nom,verif_dure,verif_per,verif_prix ;
       verif_id=true;
       verif_nom=true;
       verif_dure=true;
       verif_per=true;
       verif_prix=true;

        bool verifnom = false;
        bool verifid = false;
        bool verifper = false;
 bool verifprix = false;
 bool verifdure = false;
    QString numbers = "0123456789";
    QString alphab = "azertyuiopqsdfghjklmwxcvbnéàçAZERTYUIOPQSDFGHJKLMWXCVBN";

    int id_p = ui->lineEdit_id_4->text().toInt();
    if(( 1<=id_p) && (id_p <=99999)) {

        verifid = true;

    }

if(verifid == false ){
    verif_id = false;
    QMessageBox::information(nullptr, QObject::tr("Erreur"),
                QObject::tr("Erreur id contient seulement des nbr et moin de 99999 .\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}
    QString nom_pub= ui->lineEdit_nom_4->text();
    int v=0;
    for(int i = 0; i < nom_pub.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(nom_pub[i] == numbers[j]){
  v = 1+v;}
 //b = v +1;




                  if (v == 0)
                                          verifnom = true;
                  else if(v != 0)
                verifnom = false;
  // if (v == nom_spnsor.length())



                  }
                  if(verifnom == false ){
                      verif_nom = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur nom contient seulement des alphabets !!  .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }
    int duree = ui->lineEdit_duree_2->text().toInt();
    if(( 1<=duree) && (duree <=200)) {

        verifdure = true;

    }

if(verifdure == false ){
    verif_dure = false;
    QMessageBox::information(nullptr, QObject::tr("Erreur"),
                QObject::tr("Erreur repetition contient seulement des nbr et moin de 200fois/jr .\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}
   QString dated = ui->lineEdit_date_d_2->text();
    int period = ui->lineEdit_date_f_2->text().toInt();
    if(( 1<=period) && (period <=360)) {

        verifper = true;

    }

if(verifper == false ){
    verif_per = false;
    QMessageBox::information(nullptr, QObject::tr("Erreur"),
                QObject::tr("Erreur periode contient seulement des nbr et moin de 360 jours .\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);
}
    int prix = ui->lineEdit_prix_2->text().toInt();
   if(( 10<=prix)) {

       verifprix = true;

   }

if(verifprix == false ){
   verif_prix = false;
   QMessageBox::information(nullptr, QObject::tr("Erreur"),
               QObject::tr("Erreur prix contient seulement des nbr et prix sup de 10DT  .\n"
                           "Click Cancel to exit."), QMessageBox::Cancel);
}

   if((verif_id == true)&&(verif_nom== true) && (verif_dure==true)&&(verif_per==true)&&(verif_prix==true)){

 classpub S(id_p,nom_pub,duree, dated, period ,prix);
     bool test=S.updatep(id_p,nom_pub,duree, dated, period ,prix);


    if(test)
    {ui->tabpub->setModel(tmppub.afficherP());//refresh

        QMessageBox::information(nullptr, QObject::tr("Modifier un pub"),
                    QObject::tr("pub modifié.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    } }
    else
      {  QMessageBox::critical(nullptr, QObject::tr("Modifier Un pub"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

}}


void sponsor::on_searchp_clicked()
{ bool verif_id ;
    verif_id=true;


     bool verifid = false;
 QString numbers = "0123456789";
   QString alphab = "azertyuiopqsdfghjklmwxcvbnéàçAZERTYUIOPQSDFGHJKLMWXCVBN";
 QString val = ui->lineEdit_cin_2->text();
 int v=0;

for(int i = 0; i < val.length(); i++){
            for(int j = 0; j < alphab.length(); j++){
                if(val[i] == alphab[j]){
 v = 1+v;}
//b = v +1;

                   if (v == 0)
                                           verifid = true;
                   else if(v != 0)
                 verifid = false;

// if (v == nom_spnsor.length())


            }
            if(verifid == false ){
                verif_id = false;
                QMessageBox::information(nullptr, QObject::tr("Erreur"),
                            QObject::tr("Erreur ecrit seulement des nbr !!  .\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);

                break;
            }
        }



if(verif_id == true)

        ui->tabpub_2->setModel(tmppub.afficher2P(val));
}

void sponsor::on_pdfp_clicked()
{
    QString strStream;
       QTextStream out(&strStream);

       const int rowCount = ui->tabpub->model()->rowCount();
       const int columnCount = ui->tabpub->model()->columnCount();
       out <<"<html>\n"
             "<head>\n"
              "<meta Content=\"Text/html; charset=Windows-1251\">\n"
           << "<title>ERP - COMmANDE LIST<title>\n "
           << "</head>\n"
           "<body bgcolor=#ffffff link=#5000A0>\n"

              "<table style=\"text-align: center; font-size: 20px;\" border=1>\n "
             "</br> </br>";
       // headers
       out << "<thead><tr bgcolor=#d6e5ff>";
       for (int column = 0; column < columnCount; column++)
           if (!ui->tabpub->isColumnHidden(column))
               out << QString("<th>%1</th>").arg(ui->tabpub->model()->headerData(column, Qt::Horizontal).toString());
       out << "</tr></thead>\n";

       // data table
       for (int row = 0; row < rowCount; row++) {
           out << "<tr>";
           for (int column = 0; column < columnCount; column++) {
               if (!ui->tabpub->isColumnHidden(column)) {
                   QString data =ui->tabpub->model()->data(ui->tabpub->model()->index(row, column)).toString().simplified();
                   out << QString("<td bkcolor=0>%1</td>").arg((!data.isEmpty()) ? data : QString("&nbsp;"));
               }
           }
           out << "</tr>\n";
       }
       out <<  "</table>\n"
           "</body>\n"
           "</html>\n";

       QTextDocument *document = new QTextDocument();
       document->setHtml(strStream);

       QPrinter printer;

       QPrintDialog *dialog = new QPrintDialog(&printer, nullptr);
       if (dialog->exec() == QDialog::Accepted) {
           document->print(&printer);
       }

       delete document;
}

void sponsor::on_voir_2_clicked()
{

       ui->tabpub->setModel(tmppub.afficherP());
       ui->comboBox->setModel(tmprev.afficherref());
       ui->comboBox_2->setModel(tmprev.afficherrefp());
}

void sponsor::on_radioButton_5p_clicked()
{

       ui->tabpub->setModel(tmppub.afficher_tri_IDP());
}

void sponsor::on_radioButton_6p_clicked()
{

       ui->tabpub->setModel(tmppub.afficher_tri_ID_DESCP());
}

void sponsor::on_voir_clicked()
{

ui->tabrev->setModel(tmprev.afficherr());



}
void sponsor:: on_ajouterr_clicked()

{

    int idr = ui->comboBox->currentText().toInt();
 //int idr = ui->lineEdit_revp->text().toInt();


  bool test=tmprev.ajouterr(idr);


if(test)
{ui->tabrev->setModel(tmprev.afficherr());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter un sponsor"),
              QObject::tr("sponsor ajouté.\n"
                          "Click Cancel to exit."), QMessageBox::Cancel);

}
else
  QMessageBox::critical(nullptr, QObject::tr("Ajouter un sponsor"),
              QObject::tr("Erreur !.\n"
                          "Click Cancel to exit."), QMessageBox::Cancel);
}

void sponsor:: on_ajouterrr_clicked()
{
    int ids = ui->comboBox_2->currentText().toInt();
// int ids = ui->lineEdit_rev->text().toInt();

  bool test=tmprev.ajouterrr(ids);

if(test)
{ui->tabrev->setModel(tmprev.afficherr());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter un pub"),
              QObject::tr("pub ajouté.\n"
                          "Click Cancel to exit."), QMessageBox::Cancel);

}
else
  QMessageBox::critical(nullptr, QObject::tr("Ajouter un pub"),
              QObject::tr("Erreur !.\n"

                          "Click Cancel to exit."), QMessageBox::Cancel);

}


 void sponsor::on_searchr_clicked()
{


    bool verif_id ;
        verif_id=true;


         bool verifid = false;
      QString alphab = "azertyuiopqsdfghjklmwxcvbnéàçAZERTYUIOPQSDFGHJKLMWXCVBN";
      QString val = ui->lineEdit_cin_3->text();
    for(int i = 0; i < val.length(); i++){
                for(int j = 0; j < alphab.length(); j++){
                    if(val[i] == alphab[j]){
    //int v = 1+v;
    //b = v +1;

    // if (v == nom_spnsor.length())
                        verifid = true;

                    }
                }
                if(verifid == false ){
                    verif_id = false;
                    QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                QObject::tr("Erreur ecrit seulement une lettre  !!  .\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);

                    break;
                }
            }



    if(verif_id == true)
        ui->tabpub_4->setModel(tmprev.afficher2r(val));
}

void sponsor::on_pdfr_clicked()
{
    QString strStream;
       QTextStream out(&strStream);

       const int rowCount = ui->tabrev->model()->rowCount();
       const int columnCount = ui->tabrev->model()->columnCount();
       out <<"<html>\n"
             "<head>\n"
              "<meta Content=\"Text/html; charset=Windows-1251\">\n"
           << "<title>ERP - COMmANDE LIST<title>\n "
           << "</head>\n"
           "<body bgcolor=#ffffff link=#5000A0>\n"

              "<table style=\"text-align: center; font-size: 20px;\" border=1>\n "
             "</br> </br>";
       // headers
       out << "<thead><tr bgcolor=#d6e5ff>";
       for (int column = 0; column < columnCount; column++)
           if (!ui->tabrev->isColumnHidden(column))
               out << QString("<th>%1</th>").arg(ui->tabrev->model()->headerData(column, Qt::Horizontal).toString());
       out << "</tr></thead>\n";

       // data table
       for (int row = 0; row < rowCount; row++) {
           out << "<tr>";
           for (int column = 0; column < columnCount; column++) {
               if (!ui->tabrev->isColumnHidden(column)) {
                   QString data =ui->tabrev->model()->data(ui->tabrev->model()->index(row, column)).toString().simplified();
                   out << QString("<td bkcolor=0>%1</td>").arg((!data.isEmpty()) ? data : QString("&nbsp;"));
               }
           }
           out << "</tr>\n";
       }
       out <<  "</table>\n"
           "</body>\n"
           "</html>\n";

       QTextDocument *document = new QTextDocument();
       document->setHtml(strStream);

       QPrinter printer;

       QPrintDialog *dialog = new QPrintDialog(&printer, nullptr);
       if (dialog->exec() == QDialog::Accepted) {
           document->print(&printer);
       }

       delete document;
}


void sponsor::on_radioButton_5r_clicked()
{

       ui->tabrev->setModel(tmprev.afficher_tri_IDr());
}

void sponsor::on_radioButton_6r_clicked()
{

       ui->tabrev->setModel(tmprev.afficher_tri_ID_DESCr());
}




void sponsor::sendMail()
{
    Smtp* smtp = new Smtp(ui->uname_4->text(), ui->paswd_4->text(), ui->server_4->text(), ui->port_4->text().toInt());
    connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));
    smtp->sendMail(ui->uname_4->text(), ui->rcpt_4->text() , ui->subject_4->text(),ui->msg_4->toPlainText());
}


void sponsor::mailSent(QString status)
{
    if(status == "Message sent")
        QMessageBox::warning(nullptr, tr( "Envoi Email" ), tr( "Email envoyé!\n\n" ) );
}


void sponsor::on_lineEdit_nom_spnsor_22_textChanged(const QString &arg1)
{
     ui->tabSPON_2->setModel(tmpSPON.afficher_dyna_spon(arg1));
}

void sponsor::on_lineEdit_cin_2_textChanged(const QString &arg1)
{
     ui->tabpub_2->setModel(tmppub.afficher_dyna_pub(arg1));
}

void sponsor::on_lineEdit_cin_3_textChanged(const QString &arg1)
{
     ui->tabpub_4->setModel(tmprev.afficher_dyna_rev(arg1));
}
