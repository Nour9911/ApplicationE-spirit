#ifndef CLASSREV_H
#define CLASSREV_H
#include <QString>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QDate>
#include <QMessageBox>

class classrev
{
public:
    classrev();


    classrev(QString,int,int,int,int);
      QString get_nom_rev();

      int get_type();
      int get_sum();
      int get_idr();
      int get_ids();
      bool existeAdminr();

              bool updater(QString, int,int,int,int);
      //bool modification(int,QString,int);
              QSqlQueryModel * afficherr();
              QSqlQueryModel * afficher2r(QString);
               QSqlQueryModel * afficherref();
               QSqlQueryModel * afficherrefp();

                      void chercherr();
                      void searchr();
                      QSqlQueryModel * afficher_tri_IDr();
                      QSqlQueryModel * afficher_tri_ID_DESCr();

  QSqlQueryModel * stat();
  QSqlQueryModel * stat1();
  QSqlQueryModel * stat2();
  QSqlQueryModel * stat3();
  QSqlQueryModel * stat4();
  QSqlQueryModel * stat5();
  QSqlQueryModel * stat6();
  QSqlQueryModel * stat7();
  QSqlQueryModel * stat8();
  QSqlQueryModel * stat9();
  QSqlQueryModel * stat10();
                     bool ajouterr(int);
                     bool ajouterrr(int);

                     QSqlQueryModel * afficher_dyna_rev(QString rd);
private:
   QString nom_rev ;
   int  type , sum , idr ,ids ;


};

#endif // CLASSREV_H
