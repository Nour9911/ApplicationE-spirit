/****************************************************************************
** Meta object code from reading C++ file 'sponsor.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../projetc/sponsor.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'sponsor.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_sponsor_t {
    QByteArrayData data[26];
    char stringdata0[525];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_sponsor_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_sponsor_t qt_meta_stringdata_sponsor = {
    {
QT_MOC_LITERAL(0, 0, 7), // "sponsor"
QT_MOC_LITERAL(1, 8, 21), // "on_pb_ajouter_clicked"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 23), // "on_pb_supprimer_clicked"
QT_MOC_LITERAL(4, 55, 17), // "on_update_clicked"
QT_MOC_LITERAL(5, 73, 17), // "on_search_clicked"
QT_MOC_LITERAL(6, 91, 14), // "on_pdf_clicked"
QT_MOC_LITERAL(7, 106, 24), // "on_radioButton_5_clicked"
QT_MOC_LITERAL(8, 131, 24), // "on_radioButton_6_clicked"
QT_MOC_LITERAL(9, 156, 17), // "on_voir_3_clicked"
QT_MOC_LITERAL(10, 174, 22), // "on_pb_ajouterp_clicked"
QT_MOC_LITERAL(11, 197, 24), // "on_pb_supprimerp_clicked"
QT_MOC_LITERAL(12, 222, 18), // "on_updatep_clicked"
QT_MOC_LITERAL(13, 241, 18), // "on_searchp_clicked"
QT_MOC_LITERAL(14, 260, 15), // "on_pdfp_clicked"
QT_MOC_LITERAL(15, 276, 25), // "on_radioButton_5p_clicked"
QT_MOC_LITERAL(16, 302, 25), // "on_radioButton_6p_clicked"
QT_MOC_LITERAL(17, 328, 17), // "on_voir_2_clicked"
QT_MOC_LITERAL(18, 346, 19), // "on_ajouterr_clicked"
QT_MOC_LITERAL(19, 366, 20), // "on_ajouterrr_clicked"
QT_MOC_LITERAL(20, 387, 18), // "on_searchr_clicked"
QT_MOC_LITERAL(21, 406, 15), // "on_voir_clicked"
QT_MOC_LITERAL(22, 422, 15), // "on_pdfr_clicked"
QT_MOC_LITERAL(23, 438, 25), // "on_radioButton_5r_clicked"
QT_MOC_LITERAL(24, 464, 25), // "on_radioButton_6r_clicked"
QT_MOC_LITERAL(25, 490, 34) // "on_lineEdit_cin_3_selectionCh..."

    },
    "sponsor\0on_pb_ajouter_clicked\0\0"
    "on_pb_supprimer_clicked\0on_update_clicked\0"
    "on_search_clicked\0on_pdf_clicked\0"
    "on_radioButton_5_clicked\0"
    "on_radioButton_6_clicked\0on_voir_3_clicked\0"
    "on_pb_ajouterp_clicked\0on_pb_supprimerp_clicked\0"
    "on_updatep_clicked\0on_searchp_clicked\0"
    "on_pdfp_clicked\0on_radioButton_5p_clicked\0"
    "on_radioButton_6p_clicked\0on_voir_2_clicked\0"
    "on_ajouterr_clicked\0on_ajouterrr_clicked\0"
    "on_searchr_clicked\0on_voir_clicked\0"
    "on_pdfr_clicked\0on_radioButton_5r_clicked\0"
    "on_radioButton_6r_clicked\0"
    "on_lineEdit_cin_3_selectionChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_sponsor[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      24,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  134,    2, 0x08 /* Private */,
       3,    0,  135,    2, 0x08 /* Private */,
       4,    0,  136,    2, 0x08 /* Private */,
       5,    0,  137,    2, 0x08 /* Private */,
       6,    0,  138,    2, 0x08 /* Private */,
       7,    0,  139,    2, 0x08 /* Private */,
       8,    0,  140,    2, 0x08 /* Private */,
       9,    0,  141,    2, 0x08 /* Private */,
      10,    0,  142,    2, 0x08 /* Private */,
      11,    0,  143,    2, 0x08 /* Private */,
      12,    0,  144,    2, 0x08 /* Private */,
      13,    0,  145,    2, 0x08 /* Private */,
      14,    0,  146,    2, 0x08 /* Private */,
      15,    0,  147,    2, 0x08 /* Private */,
      16,    0,  148,    2, 0x08 /* Private */,
      17,    0,  149,    2, 0x08 /* Private */,
      18,    0,  150,    2, 0x08 /* Private */,
      19,    0,  151,    2, 0x08 /* Private */,
      20,    0,  152,    2, 0x08 /* Private */,
      21,    0,  153,    2, 0x08 /* Private */,
      22,    0,  154,    2, 0x08 /* Private */,
      23,    0,  155,    2, 0x08 /* Private */,
      24,    0,  156,    2, 0x08 /* Private */,
      25,    0,  157,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void sponsor::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        sponsor *_t = static_cast<sponsor *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pb_ajouter_clicked(); break;
        case 1: _t->on_pb_supprimer_clicked(); break;
        case 2: _t->on_update_clicked(); break;
        case 3: _t->on_search_clicked(); break;
        case 4: _t->on_pdf_clicked(); break;
        case 5: _t->on_radioButton_5_clicked(); break;
        case 6: _t->on_radioButton_6_clicked(); break;
        case 7: _t->on_voir_3_clicked(); break;
        case 8: _t->on_pb_ajouterp_clicked(); break;
        case 9: _t->on_pb_supprimerp_clicked(); break;
        case 10: _t->on_updatep_clicked(); break;
        case 11: _t->on_searchp_clicked(); break;
        case 12: _t->on_pdfp_clicked(); break;
        case 13: _t->on_radioButton_5p_clicked(); break;
        case 14: _t->on_radioButton_6p_clicked(); break;
        case 15: _t->on_voir_2_clicked(); break;
        case 16: _t->on_ajouterr_clicked(); break;
        case 17: _t->on_ajouterrr_clicked(); break;
        case 18: _t->on_searchr_clicked(); break;
        case 19: _t->on_voir_clicked(); break;
        case 20: _t->on_pdfr_clicked(); break;
        case 21: _t->on_radioButton_5r_clicked(); break;
        case 22: _t->on_radioButton_6r_clicked(); break;
        case 23: _t->on_lineEdit_cin_3_selectionChanged(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject sponsor::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_sponsor.data,
      qt_meta_data_sponsor,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *sponsor::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *sponsor::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_sponsor.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int sponsor::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 24)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 24;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 24)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 24;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
