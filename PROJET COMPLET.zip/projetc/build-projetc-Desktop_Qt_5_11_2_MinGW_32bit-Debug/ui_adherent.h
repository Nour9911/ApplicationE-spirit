/********************************************************************************
** Form generated from reading UI file 'adherent.ui'
**
** Created by: Qt User Interface Compiler version 5.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADHERENT_H
#define UI_ADHERENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_adherent
{
public:
    QTabWidget *TABLE;
    QWidget *tab_2;
    QGroupBox *groupBox_3;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *label_16;
    QLineEdit *ajouter_nom_adherent_2;
    QLineEdit *ajouter_prenom_adherent_2;
    QLineEdit *ajouter_numero_adherent_2;
    QLineEdit *ajouter_email_adherent_2;
    QPushButton *Ajouter_adherent_2;
    QSpinBox *Ajouter_nombrepts_adherent_2;
    QLabel *label_17;
    QLineEdit *ajouter_id_adherent_2;
    QDateEdit *ajout_date_ajout;
    QLabel *label_35;
    QPushButton *supprimer_adherent_3;
    QTableView *table_adherent;
    QLineEdit *supprimer_adherent;
    QRadioButton *tri_desc;
    QRadioButton *tri_asc;
    QWidget *tab_3;
    QGroupBox *groupBox_5;
    QLabel *label_23;
    QLabel *label_24;
    QLabel *label_25;
    QLabel *label_26;
    QLineEdit *modifier_nom_adherent;
    QLineEdit *modifier_prenom_adherent;
    QLineEdit *modifier_numero_adherent;
    QLineEdit *modifier_email_adherent;
    QPushButton *modifier_adherent;
    QLabel *label_28;
    QLineEdit *modifier_id_adherent;
    QLabel *label_27;
    QSpinBox *modifier_pts_adherent;
    QLineEdit *chercher_adherent;
    QPushButton *chercher_modif_adherent;
    QTableView *table_Re_adherent;
    QLabel *label_5;
    QWidget *tab_5;
    QGroupBox *groupBox_4;
    QLabel *label_18;
    QLabel *label_19;
    QLabel *label_20;
    QLineEdit *Ajouter_id_cadeau_2;
    QLineEdit *ajouter_nom_cadeau_2;
    QPushButton *Ajouter_cadeau_2;
    QSpinBox *Ajouter_nombrepts_cadeau_2;
    QPushButton *supprimer_cadeau_2;
    QLabel *label_22;
    QTableView *table_cadeau_2;
    QLineEdit *supprimer_cadeau;
    QRadioButton *tri_asc_cad;
    QRadioButton *tri_desc_cad;
    QGroupBox *groupBox_8;
    QLabel *label_37;
    QLabel *label_38;
    QPushButton *affecter_cadeau_adh;
    QComboBox *combo_id_adh_2;
    QComboBox *combo_id_cad_2;
    QWidget *tab_4;
    QGroupBox *groupBox_6;
    QLabel *label_29;
    QLabel *label_30;
    QLabel *label_31;
    QLineEdit *modifier_id_cadeau;
    QLineEdit *modifier_nom_cadeau;
    QPushButton *modifier_cadeau;
    QSpinBox *modifier_pts_cadeau;
    QLineEdit *recherche_cadeau_id;
    QPushButton *chercher_cadeau;
    QTableView *table_Re_cadeau;
    QLabel *label_4;
    QWidget *tab_6;
    QLabel *label_2;
    QPushButton *statistique;
    QWidget *tab;
    QLabel *label_3;

    void setupUi(QDialog *adherent)
    {
        if (adherent->objectName().isEmpty())
            adherent->setObjectName(QStringLiteral("adherent"));
        adherent->resize(1233, 724);
        TABLE = new QTabWidget(adherent);
        TABLE->setObjectName(QStringLiteral("TABLE"));
        TABLE->setGeometry(QRect(0, 0, 1241, 731));
        TABLE->setStyleSheet(QStringLiteral("background-color: rgb(42, 41, 46);"));
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        groupBox_3 = new QGroupBox(tab_2);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(10, 50, 351, 441));
        groupBox_3->setStyleSheet(QLatin1String("font: 15pt \"MS Shell Dlg 2\";\n"
"background-color: rgb(21, 30, 45);\n"
"color: rgb(255, 255, 255);"));
        label_12 = new QLabel(groupBox_3);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(20, 100, 55, 16));
        label_12->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        label_13 = new QLabel(groupBox_3);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(20, 150, 61, 21));
        label_13->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        label_14 = new QLabel(groupBox_3);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(20, 200, 71, 16));
        label_14->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        label_15 = new QLabel(groupBox_3);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(20, 250, 61, 16));
        label_15->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        label_16 = new QLabel(groupBox_3);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(10, 300, 161, 16));
        label_16->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        ajouter_nom_adherent_2 = new QLineEdit(groupBox_3);
        ajouter_nom_adherent_2->setObjectName(QStringLiteral("ajouter_nom_adherent_2"));
        ajouter_nom_adherent_2->setGeometry(QRect(190, 100, 113, 22));
        ajouter_nom_adherent_2->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;\n"
""));
        ajouter_prenom_adherent_2 = new QLineEdit(groupBox_3);
        ajouter_prenom_adherent_2->setObjectName(QStringLiteral("ajouter_prenom_adherent_2"));
        ajouter_prenom_adherent_2->setGeometry(QRect(190, 150, 113, 22));
        ajouter_prenom_adherent_2->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        ajouter_numero_adherent_2 = new QLineEdit(groupBox_3);
        ajouter_numero_adherent_2->setObjectName(QStringLiteral("ajouter_numero_adherent_2"));
        ajouter_numero_adherent_2->setGeometry(QRect(190, 200, 113, 22));
        ajouter_numero_adherent_2->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        ajouter_email_adherent_2 = new QLineEdit(groupBox_3);
        ajouter_email_adherent_2->setObjectName(QStringLiteral("ajouter_email_adherent_2"));
        ajouter_email_adherent_2->setGeometry(QRect(190, 250, 113, 22));
        ajouter_email_adherent_2->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        Ajouter_adherent_2 = new QPushButton(groupBox_3);
        Ajouter_adherent_2->setObjectName(QStringLiteral("Ajouter_adherent_2"));
        Ajouter_adherent_2->setGeometry(QRect(210, 400, 101, 28));
        Ajouter_adherent_2->setStyleSheet(QLatin1String("color: white;\n"
"                                         \n"
"font: 63 10pt \"Myriad Pro Light\";\n"
"background-color: rgb(106, 110, 246);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        Ajouter_adherent_2->setAutoDefault(true);
        Ajouter_nombrepts_adherent_2 = new QSpinBox(groupBox_3);
        Ajouter_nombrepts_adherent_2->setObjectName(QStringLiteral("Ajouter_nombrepts_adherent_2"));
        Ajouter_nombrepts_adherent_2->setGeometry(QRect(190, 300, 111, 22));
        Ajouter_nombrepts_adherent_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_17 = new QLabel(groupBox_3);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(20, 50, 91, 16));
        label_17->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        ajouter_id_adherent_2 = new QLineEdit(groupBox_3);
        ajouter_id_adherent_2->setObjectName(QStringLiteral("ajouter_id_adherent_2"));
        ajouter_id_adherent_2->setGeometry(QRect(190, 50, 113, 22));
        ajouter_id_adherent_2->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        ajout_date_ajout = new QDateEdit(groupBox_3);
        ajout_date_ajout->setObjectName(QStringLiteral("ajout_date_ajout"));
        ajout_date_ajout->setGeometry(QRect(190, 350, 131, 22));
        ajout_date_ajout->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        ajout_date_ajout->setDateTime(QDateTime(QDate(2020, 4, 15), QTime(0, 0, 0)));
        ajout_date_ajout->setMaximumDateTime(QDateTime(QDate(2050, 12, 31), QTime(23, 59, 59)));
        ajout_date_ajout->setMinimumDateTime(QDateTime(QDate(2020, 1, 1), QTime(0, 0, 0)));
        ajout_date_ajout->setCurrentSection(QDateTimeEdit::YearSection);
        ajout_date_ajout->setCalendarPopup(true);
        ajout_date_ajout->setTimeSpec(Qt::TimeZone);
        label_35 = new QLabel(groupBox_3);
        label_35->setObjectName(QStringLiteral("label_35"));
        label_35->setGeometry(QRect(20, 350, 161, 16));
        label_35->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        supprimer_adherent_3 = new QPushButton(tab_2);
        supprimer_adherent_3->setObjectName(QStringLiteral("supprimer_adherent_3"));
        supprimer_adherent_3->setGeometry(QRect(40, 500, 191, 31));
        supprimer_adherent_3->setStyleSheet(QLatin1String("color: white;\n"
"                                         \n"
"font: 63 10pt \"Myriad Pro Light\";\n"
"background-color: rgb(106, 110, 246);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;\n"
""));
        table_adherent = new QTableView(tab_2);
        table_adherent->setObjectName(QStringLiteral("table_adherent"));
        table_adherent->setGeometry(QRect(390, 70, 801, 531));
        table_adherent->setMouseTracking(false);
        table_adherent->setLayoutDirection(Qt::LeftToRight);
        table_adherent->setStyleSheet(QLatin1String("color: black;\n"
"                                        \n"
"background-color: rgb(245, 245, 245);\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        supprimer_adherent = new QLineEdit(tab_2);
        supprimer_adherent->setObjectName(QStringLiteral("supprimer_adherent"));
        supprimer_adherent->setGeometry(QRect(250, 500, 91, 31));
        supprimer_adherent->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        tri_desc = new QRadioButton(tab_2);
        tri_desc->setObjectName(QStringLiteral("tri_desc"));
        tri_desc->setGeometry(QRect(790, 30, 121, 31));
        tri_desc->setStyleSheet(QLatin1String("color: white;\n"
"                                         \n"
"background-color: rgb(255, 0, 0);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        tri_asc = new QRadioButton(tab_2);
        tri_asc->setObjectName(QStringLiteral("tri_asc"));
        tri_asc->setGeometry(QRect(660, 30, 111, 31));
        tri_asc->setStyleSheet(QLatin1String("color: white;\n"
"                                         \n"
"background-color: rgb(255, 0, 0);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        TABLE->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        groupBox_5 = new QGroupBox(tab_3);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        groupBox_5->setGeometry(QRect(40, 50, 351, 391));
        groupBox_5->setStyleSheet(QLatin1String("font: 15pt \"MS Shell Dlg 2\";\n"
"background-color: rgb(21, 30, 45);\n"
"color: rgb(255, 255, 255);"));
        label_23 = new QLabel(groupBox_5);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(20, 100, 55, 16));
        label_23->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        label_24 = new QLabel(groupBox_5);
        label_24->setObjectName(QStringLiteral("label_24"));
        label_24->setGeometry(QRect(20, 150, 61, 21));
        label_24->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        label_25 = new QLabel(groupBox_5);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setGeometry(QRect(20, 200, 71, 16));
        label_25->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        label_26 = new QLabel(groupBox_5);
        label_26->setObjectName(QStringLiteral("label_26"));
        label_26->setGeometry(QRect(20, 250, 61, 16));
        label_26->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        modifier_nom_adherent = new QLineEdit(groupBox_5);
        modifier_nom_adherent->setObjectName(QStringLiteral("modifier_nom_adherent"));
        modifier_nom_adherent->setGeometry(QRect(190, 100, 113, 22));
        modifier_nom_adherent->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        modifier_prenom_adherent = new QLineEdit(groupBox_5);
        modifier_prenom_adherent->setObjectName(QStringLiteral("modifier_prenom_adherent"));
        modifier_prenom_adherent->setGeometry(QRect(190, 150, 113, 22));
        modifier_prenom_adherent->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        modifier_numero_adherent = new QLineEdit(groupBox_5);
        modifier_numero_adherent->setObjectName(QStringLiteral("modifier_numero_adherent"));
        modifier_numero_adherent->setGeometry(QRect(190, 200, 113, 22));
        modifier_numero_adherent->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;\n"
""));
        modifier_email_adherent = new QLineEdit(groupBox_5);
        modifier_email_adherent->setObjectName(QStringLiteral("modifier_email_adherent"));
        modifier_email_adherent->setGeometry(QRect(190, 250, 113, 22));
        modifier_email_adherent->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        modifier_adherent = new QPushButton(groupBox_5);
        modifier_adherent->setObjectName(QStringLiteral("modifier_adherent"));
        modifier_adherent->setGeometry(QRect(200, 350, 101, 28));
        modifier_adherent->setStyleSheet(QLatin1String("color: white;\n"
"                                         \n"
"font: 63 10pt \"Myriad Pro Light\";\n"
"background-color: rgb(106, 110, 246);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        label_28 = new QLabel(groupBox_5);
        label_28->setObjectName(QStringLiteral("label_28"));
        label_28->setGeometry(QRect(20, 50, 91, 16));
        label_28->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        modifier_id_adherent = new QLineEdit(groupBox_5);
        modifier_id_adherent->setObjectName(QStringLiteral("modifier_id_adherent"));
        modifier_id_adherent->setGeometry(QRect(190, 50, 113, 22));
        modifier_id_adherent->setStyleSheet(QLatin1String("color: rgb(170, 0, 0);\n"
"color: white;\n"
"                                         \n"
"background-color: rgb(51, 51, 51);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        label_27 = new QLabel(groupBox_5);
        label_27->setObjectName(QStringLiteral("label_27"));
        label_27->setGeometry(QRect(10, 310, 161, 16));
        label_27->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        modifier_pts_adherent = new QSpinBox(groupBox_5);
        modifier_pts_adherent->setObjectName(QStringLiteral("modifier_pts_adherent"));
        modifier_pts_adherent->setGeometry(QRect(190, 310, 111, 22));
        modifier_pts_adherent->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        chercher_adherent = new QLineEdit(tab_3);
        chercher_adherent->setObjectName(QStringLiteral("chercher_adherent"));
        chercher_adherent->setGeometry(QRect(630, 120, 151, 31));
        chercher_adherent->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        chercher_modif_adherent = new QPushButton(tab_3);
        chercher_modif_adherent->setObjectName(QStringLiteral("chercher_modif_adherent"));
        chercher_modif_adherent->setGeometry(QRect(810, 120, 241, 28));
        chercher_modif_adherent->setStyleSheet(QLatin1String("color: white;\n"
"                                         \n"
"font: 63 10pt \"Myriad Pro Light\";\n"
"background-color: rgb(106, 110, 246);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        table_Re_adherent = new QTableView(tab_3);
        table_Re_adherent->setObjectName(QStringLiteral("table_Re_adherent"));
        table_Re_adherent->setGeometry(QRect(410, 170, 811, 201));
        table_Re_adherent->setStyleSheet(QLatin1String("color: black;\n"
"                                        \n"
"background-color: rgb(245, 245, 245);\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        label_5 = new QLabel(tab_3);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(-20, -100, 1291, 821));
        label_5->setPixmap(QPixmap(QString::fromUtf8("../../Downloads/e-sport.jpg")));
        TABLE->addTab(tab_3, QString());
        label_5->raise();
        groupBox_5->raise();
        chercher_adherent->raise();
        chercher_modif_adherent->raise();
        table_Re_adherent->raise();
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        groupBox_4 = new QGroupBox(tab_5);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setGeometry(QRect(20, 20, 391, 331));
        groupBox_4->setStyleSheet(QLatin1String("font: 15pt \"MS Shell Dlg 2\";\n"
"background-color: rgb(21, 30, 45);\n"
"color: rgb(255, 255, 255);"));
        label_18 = new QLabel(groupBox_4);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(30, 60, 81, 16));
        label_18->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        label_19 = new QLabel(groupBox_4);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(30, 110, 61, 21));
        label_19->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        label_20 = new QLabel(groupBox_4);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setGeometry(QRect(30, 160, 141, 16));
        label_20->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        Ajouter_id_cadeau_2 = new QLineEdit(groupBox_4);
        Ajouter_id_cadeau_2->setObjectName(QStringLiteral("Ajouter_id_cadeau_2"));
        Ajouter_id_cadeau_2->setGeometry(QRect(260, 60, 113, 22));
        Ajouter_id_cadeau_2->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        ajouter_nom_cadeau_2 = new QLineEdit(groupBox_4);
        ajouter_nom_cadeau_2->setObjectName(QStringLiteral("ajouter_nom_cadeau_2"));
        ajouter_nom_cadeau_2->setGeometry(QRect(260, 110, 113, 22));
        ajouter_nom_cadeau_2->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        Ajouter_cadeau_2 = new QPushButton(groupBox_4);
        Ajouter_cadeau_2->setObjectName(QStringLiteral("Ajouter_cadeau_2"));
        Ajouter_cadeau_2->setGeometry(QRect(260, 280, 111, 28));
        Ajouter_cadeau_2->setStyleSheet(QLatin1String("color: white;\n"
"                                         \n"
"background-color: rgb(255, 0, 0);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        Ajouter_nombrepts_cadeau_2 = new QSpinBox(groupBox_4);
        Ajouter_nombrepts_cadeau_2->setObjectName(QStringLiteral("Ajouter_nombrepts_cadeau_2"));
        Ajouter_nombrepts_cadeau_2->setGeometry(QRect(260, 170, 111, 22));
        Ajouter_nombrepts_cadeau_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        supprimer_cadeau_2 = new QPushButton(tab_5);
        supprimer_cadeau_2->setObjectName(QStringLiteral("supprimer_cadeau_2"));
        supprimer_cadeau_2->setGeometry(QRect(40, 360, 191, 31));
        supprimer_cadeau_2->setStyleSheet(QLatin1String("color: white;\n"
"                                         \n"
"background-color: rgb(255, 0, 0);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        label_22 = new QLabel(tab_5);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(-70, -150, 1301, 851));
        label_22->setPixmap(QPixmap(QString::fromUtf8("../../Downloads/e-sport.jpg")));
        table_cadeau_2 = new QTableView(tab_5);
        table_cadeau_2->setObjectName(QStringLiteral("table_cadeau_2"));
        table_cadeau_2->setGeometry(QRect(460, 100, 751, 531));
        table_cadeau_2->setStyleSheet(QLatin1String("color: black;\n"
"                                        \n"
"background-color: rgb(245, 245, 245);\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        supprimer_cadeau = new QLineEdit(tab_5);
        supprimer_cadeau->setObjectName(QStringLiteral("supprimer_cadeau"));
        supprimer_cadeau->setGeometry(QRect(250, 360, 131, 31));
        supprimer_cadeau->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        tri_asc_cad = new QRadioButton(tab_5);
        tri_asc_cad->setObjectName(QStringLiteral("tri_asc_cad"));
        tri_asc_cad->setGeometry(QRect(700, 60, 111, 31));
        tri_asc_cad->setStyleSheet(QLatin1String("color: white;\n"
"                                         \n"
"background-color: rgb(255, 0, 0);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        tri_desc_cad = new QRadioButton(tab_5);
        tri_desc_cad->setObjectName(QStringLiteral("tri_desc_cad"));
        tri_desc_cad->setGeometry(QRect(840, 60, 121, 31));
        tri_desc_cad->setStyleSheet(QLatin1String("color: white;\n"
"                                         \n"
"background-color: rgb(255, 0, 0);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        groupBox_8 = new QGroupBox(tab_5);
        groupBox_8->setObjectName(QStringLiteral("groupBox_8"));
        groupBox_8->setGeometry(QRect(20, 450, 401, 231));
        groupBox_8->setStyleSheet(QLatin1String("font: 15pt \"MS Shell Dlg 2\";\n"
"background-color: rgb(21, 30, 45);\n"
"color: rgb(255, 255, 255);"));
        label_37 = new QLabel(groupBox_8);
        label_37->setObjectName(QStringLiteral("label_37"));
        label_37->setGeometry(QRect(30, 60, 201, 16));
        label_37->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        label_38 = new QLabel(groupBox_8);
        label_38->setObjectName(QStringLiteral("label_38"));
        label_38->setGeometry(QRect(30, 110, 171, 21));
        label_38->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        affecter_cadeau_adh = new QPushButton(groupBox_8);
        affecter_cadeau_adh->setObjectName(QStringLiteral("affecter_cadeau_adh"));
        affecter_cadeau_adh->setGeometry(QRect(260, 170, 111, 28));
        affecter_cadeau_adh->setStyleSheet(QLatin1String("color: white;\n"
"                                         \n"
"background-color: rgb(255, 0, 0);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        combo_id_adh_2 = new QComboBox(groupBox_8);
        combo_id_adh_2->setObjectName(QStringLiteral("combo_id_adh_2"));
        combo_id_adh_2->setGeometry(QRect(260, 51, 121, 31));
        combo_id_adh_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        combo_id_cad_2 = new QComboBox(groupBox_8);
        combo_id_cad_2->setObjectName(QStringLiteral("combo_id_cad_2"));
        combo_id_cad_2->setGeometry(QRect(260, 101, 121, 31));
        combo_id_cad_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        TABLE->addTab(tab_5, QString());
        label_22->raise();
        groupBox_4->raise();
        supprimer_cadeau_2->raise();
        table_cadeau_2->raise();
        supprimer_cadeau->raise();
        tri_asc_cad->raise();
        tri_desc_cad->raise();
        groupBox_8->raise();
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        groupBox_6 = new QGroupBox(tab_4);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        groupBox_6->setGeometry(QRect(20, 80, 401, 311));
        groupBox_6->setStyleSheet(QLatin1String("font: 15pt \"MS Shell Dlg 2\";\n"
"background-color: rgb(21, 30, 45);\n"
"color: rgb(255, 255, 255);"));
        label_29 = new QLabel(groupBox_6);
        label_29->setObjectName(QStringLiteral("label_29"));
        label_29->setGeometry(QRect(30, 60, 81, 16));
        label_29->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        label_30 = new QLabel(groupBox_6);
        label_30->setObjectName(QStringLiteral("label_30"));
        label_30->setGeometry(QRect(30, 110, 61, 21));
        label_30->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        label_31 = new QLabel(groupBox_6);
        label_31->setObjectName(QStringLiteral("label_31"));
        label_31->setGeometry(QRect(30, 160, 141, 16));
        label_31->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        modifier_id_cadeau = new QLineEdit(groupBox_6);
        modifier_id_cadeau->setObjectName(QStringLiteral("modifier_id_cadeau"));
        modifier_id_cadeau->setGeometry(QRect(260, 60, 113, 22));
        modifier_id_cadeau->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        modifier_nom_cadeau = new QLineEdit(groupBox_6);
        modifier_nom_cadeau->setObjectName(QStringLiteral("modifier_nom_cadeau"));
        modifier_nom_cadeau->setGeometry(QRect(260, 110, 113, 22));
        modifier_nom_cadeau->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        modifier_cadeau = new QPushButton(groupBox_6);
        modifier_cadeau->setObjectName(QStringLiteral("modifier_cadeau"));
        modifier_cadeau->setGeometry(QRect(260, 260, 111, 28));
        modifier_cadeau->setStyleSheet(QLatin1String("color: white;\n"
"                                         \n"
"background-color: rgb(255, 0, 0);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        modifier_pts_cadeau = new QSpinBox(groupBox_6);
        modifier_pts_cadeau->setObjectName(QStringLiteral("modifier_pts_cadeau"));
        modifier_pts_cadeau->setGeometry(QRect(270, 160, 101, 22));
        modifier_pts_cadeau->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        recherche_cadeau_id = new QLineEdit(tab_4);
        recherche_cadeau_id->setObjectName(QStringLiteral("recherche_cadeau_id"));
        recherche_cadeau_id->setGeometry(QRect(870, 70, 151, 31));
        recherche_cadeau_id->setStyleSheet(QLatin1String("color: black;\n"
"                                         background-color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        chercher_cadeau = new QPushButton(tab_4);
        chercher_cadeau->setObjectName(QStringLiteral("chercher_cadeau"));
        chercher_cadeau->setGeometry(QRect(610, 70, 241, 28));
        chercher_cadeau->setStyleSheet(QLatin1String("color: white;\n"
"                                         \n"
"background-color: rgb(255, 0, 0);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        table_Re_cadeau = new QTableView(tab_4);
        table_Re_cadeau->setObjectName(QStringLiteral("table_Re_cadeau"));
        table_Re_cadeau->setGeometry(QRect(510, 120, 671, 141));
        table_Re_cadeau->setStyleSheet(QLatin1String("color: black;\n"
"                                        \n"
"background-color: rgb(245, 245, 245);\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        label_4 = new QLabel(tab_4);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(0, -180, 1291, 881));
        label_4->setPixmap(QPixmap(QString::fromUtf8("../../Downloads/e-sport.jpg")));
        TABLE->addTab(tab_4, QString());
        label_4->raise();
        groupBox_6->raise();
        recherche_cadeau_id->raise();
        chercher_cadeau->raise();
        table_Re_cadeau->raise();
        tab_6 = new QWidget();
        tab_6->setObjectName(QStringLiteral("tab_6"));
        label_2 = new QLabel(tab_6);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(-30, -100, 1291, 821));
        label_2->setPixmap(QPixmap(QString::fromUtf8("../../Downloads/e-sport.jpg")));
        statistique = new QPushButton(tab_6);
        statistique->setObjectName(QStringLiteral("statistique"));
        statistique->setGeometry(QRect(100, 240, 331, 121));
        TABLE->addTab(tab_6, QString());
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        label_3 = new QLabel(tab);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(-20, 0, 1291, 791));
        label_3->setPixmap(QPixmap(QString::fromUtf8("../../Downloads/e-sport.jpg")));
        TABLE->addTab(tab, QString());

        retranslateUi(adherent);

        TABLE->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(adherent);
    } // setupUi

    void retranslateUi(QDialog *adherent)
    {
        adherent->setWindowTitle(QApplication::translate("adherent", "Dialog", nullptr));
        groupBox_3->setTitle(QApplication::translate("adherent", "Ajouter votre adh\303\251rent", nullptr));
        label_12->setText(QApplication::translate("adherent", "Nom", nullptr));
        label_13->setText(QApplication::translate("adherent", "Pr\303\251nom", nullptr));
        label_14->setText(QApplication::translate("adherent", "Num\303\251ro", nullptr));
        label_15->setText(QApplication::translate("adherent", "Email", nullptr));
        label_16->setText(QApplication::translate("adherent", " Nombre de points", nullptr));
        Ajouter_adherent_2->setText(QApplication::translate("adherent", "Ajouter", nullptr));
        label_17->setText(QApplication::translate("adherent", "Identifiant", nullptr));
        ajouter_id_adherent_2->setText(QString());
        label_35->setText(QApplication::translate("adherent", "Date d'ajout", nullptr));
        supprimer_adherent_3->setText(QApplication::translate("adherent", "Supprimer par identifiant", nullptr));
        supprimer_adherent->setText(QString());
        tri_desc->setText(QApplication::translate("adherent", "Decroissant", nullptr));
        tri_asc->setText(QApplication::translate("adherent", "Croissant", nullptr));
        TABLE->setTabText(TABLE->indexOf(tab_2), QApplication::translate("adherent", "Adh\303\251rent", nullptr));
        groupBox_5->setTitle(QApplication::translate("adherent", "Modifier votre adh\303\251rent", nullptr));
        label_23->setText(QApplication::translate("adherent", "Nom", nullptr));
        label_24->setText(QApplication::translate("adherent", "Pr\303\251nom", nullptr));
        label_25->setText(QApplication::translate("adherent", "Num\303\251ro", nullptr));
        label_26->setText(QApplication::translate("adherent", "Email", nullptr));
        modifier_adherent->setText(QApplication::translate("adherent", "Modifier", nullptr));
        label_28->setText(QApplication::translate("adherent", "Identifiant", nullptr));
        label_27->setText(QApplication::translate("adherent", " Nombre de points", nullptr));
        chercher_modif_adherent->setText(QApplication::translate("adherent", "Chercher adh\303\251rent par identifiant", nullptr));
        label_5->setText(QString());
        TABLE->setTabText(TABLE->indexOf(tab_3), QApplication::translate("adherent", "Modifier adh\303\251rent", nullptr));
        groupBox_4->setTitle(QApplication::translate("adherent", "Ajouter votre cadeau", nullptr));
        label_18->setText(QApplication::translate("adherent", "Identifiant", nullptr));
        label_19->setText(QApplication::translate("adherent", "Nom", nullptr));
        label_20->setText(QApplication::translate("adherent", "Nombre de points", nullptr));
        Ajouter_cadeau_2->setText(QApplication::translate("adherent", "Ajouter", nullptr));
        supprimer_cadeau_2->setText(QApplication::translate("adherent", "Supprimer par Identifiant", nullptr));
        label_22->setText(QString());
        tri_asc_cad->setText(QApplication::translate("adherent", "Croissant", nullptr));
        tri_desc_cad->setText(QApplication::translate("adherent", "Decroissant", nullptr));
        groupBox_8->setTitle(QApplication::translate("adherent", "Affecter un cadeau", nullptr));
        label_37->setText(QApplication::translate("adherent", "Identifiant de l'adh\303\251rent", nullptr));
        label_38->setText(QApplication::translate("adherent", "Identifiant du cadeau", nullptr));
        affecter_cadeau_adh->setText(QApplication::translate("adherent", "Affecter", nullptr));
        TABLE->setTabText(TABLE->indexOf(tab_5), QApplication::translate("adherent", "Cadeaux", nullptr));
        groupBox_6->setTitle(QApplication::translate("adherent", "Modifier votre cadeau", nullptr));
        label_29->setText(QApplication::translate("adherent", "Identifiant", nullptr));
        label_30->setText(QApplication::translate("adherent", "Nom", nullptr));
        label_31->setText(QApplication::translate("adherent", "Nombre de points", nullptr));
        modifier_id_cadeau->setText(QString());
        modifier_cadeau->setText(QApplication::translate("adherent", "Modifier", nullptr));
        chercher_cadeau->setText(QApplication::translate("adherent", "Chercher le cadeau par identifiant", nullptr));
        label_4->setText(QString());
        TABLE->setTabText(TABLE->indexOf(tab_4), QApplication::translate("adherent", "Modifier cadeau", nullptr));
        label_2->setText(QString());
        statistique->setText(QApplication::translate("adherent", "stat", nullptr));
        TABLE->setTabText(TABLE->indexOf(tab_6), QApplication::translate("adherent", "Statistique adh\303\251rent", nullptr));
        label_3->setText(QString());
        TABLE->setTabText(TABLE->indexOf(tab), QString());
    } // retranslateUi

};

namespace Ui {
    class adherent: public Ui_adherent {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADHERENT_H
