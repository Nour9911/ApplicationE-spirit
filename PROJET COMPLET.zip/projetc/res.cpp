#include "res.h"
#include "ui_res.h"
#include <QMessageBox>
#include "reservation.h"
#include "ticket.h"
#include <QSqlQuery>
#include <QDebug>
#include <QVariant>
#include <QPixmap>
#include "smtp.h"

res::res(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::res)
{
    ui->setupUi(this);
    connect(ui->sendBtn_3, SIGNAL(clicked()),this, SLOT(sendMail()));
    connect(ui->exitBtn_3, SIGNAL(clicked()),this, SLOT(close()));
    this->setWindowTitle("GESTION DES RESERVATIONS ET TICKETS");
    this->setWindowIcon(QIcon("../projetc/e-spirit.png"));
    QPixmap pix(":/new/prefix1/img/background.jpg");
    ui->table_res->setModel(tmpreservation.afficher_reservation());
    ui->table_ticket->setModel(tmpticket.afficher_ticket());



    int w= ui->label_res1->width();
    int h= ui->label_res1->height();
    int w1= ui->label_res2->width();
    int h1= ui->label_res2->height();
    int w2= ui->label_res3->width();
    int h2= ui->label_res3->height();
    int w3= ui->label_res4->width();
    int h3= ui->label_res4->height();
    int w4= ui->label_res5->width();
    int h4= ui->label_res5->height();


    ui->label_res1->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
    ui->label_res2->setPixmap(pix.scaled(w1,h1,Qt::KeepAspectRatio));
    ui->label_res3->setPixmap(pix.scaled(w2,h2,Qt::KeepAspectRatio));
    ui->label_res4->setPixmap(pix.scaled(w3,h3,Qt::KeepAspectRatio));
    ui->label_res5->setPixmap(pix.scaled(w4,h4,Qt::KeepAspectRatio));




    QSqlQuery query;
    query.prepare("select Id_reservation from reservation");
    if(query.exec())
        {
            while(query.next())
            {
                QString s = query.value(0).toString();//Récupère le résultat de la requête
                ui->combo_Id_res_2->addItem(s);

            }
        }


    query.prepare("select Idt from ticket");
    if(query.exec())
        {
            while(query.next())
            {
                QString s = query.value(0).toString();
                ui->combo_Idt_2->addItem(s);
            }
        }
}

res::~res()
{
    delete ui;
}

void res::on_ajouter_res_clicked()
{
    bool verif_Id_reservation,verif_Nom,verif_Prenom;

    bool verifID=false;
    bool verifNOM=false;
    bool verifPRENOM=false;



    verif_Id_reservation=true;
    verif_Nom=true;
    verif_Prenom=true;



    QString numbers = "0123456789";
    QString alphab = "azertyuiopqsdfghjklmwxcvbnéàçAZERTYUIOPQSDFGHJKLMWXCVBN";

    QString Id_reservation = ui->ajouter_id->text();
    for(int i = 0; i < Id_reservation.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(Id_reservation[i] == numbers[j]){
                          verifID = true;
                      }
                  }
                  if(verifID == false ){
                      verif_Id_reservation = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur id invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }
    QString Nom = ui->ajouter_nom->text();
    int v=0;
    for(int i = 0; i < Nom.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(Nom[i] == numbers[j]){
                           v = v +1;
                      }
                      if (v == 0)
                                              verifNOM = true;
                      else if(v != 0)
                    verifNOM = false;
                  }
                  if(verifNOM == false ){
                      verif_Nom = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur Nom invalide.\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }

    QString Prenom = ui->ajouter_prenom->text();
    for(int i = 0; i < Prenom.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(Prenom[i] == numbers[j]){
                          v = v +1;

                      }
                      if (v == 0)
                          verifPRENOM = true;
                      else if(v != 0)
                    verifPRENOM = false;
                  }
                  if(verifPRENOM == false ){
                      verif_Prenom = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur prenom invalide.\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }
    QString type_place = ui->ajouter_type_place->text();
    QString type_payment = ui->ajouter_type_payment->text();
    QString payment = ui->ajouter_payment->text();

    if((verif_Id_reservation == true)&&(verif_Nom == true) && (verif_Prenom == true)){
    reservation re(Id_reservation,Nom,Prenom,type_place,type_payment,payment);
    bool test=re.ajouter_reservation();

    if(test)
    {
        ui->combo_Id_res_2->setModel(tmpticket.refresh_Id_res());
        ui->table_res->setModel(tmpreservation.afficher_reservation());
        QMessageBox::information(nullptr, QObject::tr("Ajouter une reservation"),QObject::tr("reservation ajoutee.\n""Click cancel to exit."),QMessageBox::Cancel);
    }
}
}


QSqlQueryModel* reservation::afficher_reservation()
{
    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("SELECT * FROM reservation");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Id_reservation "));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prenom"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("type_place"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("type_payment"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("payment"));

    return model;
}


void res::on_supprimer_res_clicked()
{
    QString id = ui->supprimer_res_2->text();
    bool test = tmpreservation.supprimer_reservation(id);

    if(test)
    {
        ui->table_res->setModel(tmpreservation.afficher_reservation());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer une reservation"),
                        QObject::tr("reservation supprimée.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

        }
        else
            QMessageBox::critical(nullptr, QObject::tr("Supprimer une reservation"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);


    }



void res::on_chercher_modif_res_clicked()
{

    QString Id_reservation = ui->chercher_res->text();

        ui->table_Re_res->setModel(tmpreservation.afficher_Re_reservation(Id_reservation));//refresh

}


void res::on_modifier_res_clicked()
{


        QString Id_reservation = ui->modifier_id->text();
        QString Nom = ui->modifier_nom->text();
        QString Prenom = ui->modifier_prenom->text();
        QString type_place = ui->modifier_type_place->text();
        QString type_payment = ui->modifier_type_payment->text();
        QString payment= ui->modifier_payment->text();

    bool test=tmpreservation.modifier_reservation(Id_reservation,Nom,Prenom,type_place,type_payment,payment);


    if (test)
      {
        ui->table_res->setModel(tmpreservation.afficher_reservation());//refresh
        ui->table_Re_res->setModel(tmpreservation.afficher_Re_reservation(Id_reservation));//refresh

    QMessageBox::information(nullptr, QObject::tr("modifier une reservation"),
                    QObject::tr("reservation modifiee.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("modifier une reservation"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}


void res::on_tri_asc_res_clicked()
{
    ui->table_res->setModel(tmpreservation.afficher_tri_ID());

}

void res::on_tri_desc_res_clicked()
{
    ui->table_res->setModel(tmpreservation.afficher_tri_ID_DESC());
}


void res::on_ajouter_ticket_clicked()
{
    bool verifIDt=false;

    bool verif_Idt=true;

    QString numbers = "0123456789";
    QString alphab = "azertyuiopqsdfghjklmwxcvbnéàçAZERTYUIOPQSDFGHJKLMWXCVBN";

    QString Id_res;
    QString Idt = ui->ajouter_idt->text();
    for(int i = 0; i < Idt.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(Idt[i] == numbers[j]){
                          verifIDt = true;
                      }
                  }
                  if(verifIDt == false ){
                      verif_Idt = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur id invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }
    QString tp = ui->ajouter_tp->text();

     if(verif_Idt == true){
    ticket ti(Id_res,Idt,tp);
    bool test=ti.ajouter_ticket();

    if(test)
    {
        ui->combo_Idt_2->setModel(tmpticket.refresh_Idt());
        ui->table_ticket->setModel(tmpticket.afficher_ticket());
        QMessageBox::information(nullptr, QObject::tr("Ajouter un ticket"),QObject::tr("ticket ajoute.\n""Click cancel to exit."),QMessageBox::Cancel);
    }
}
}


QSqlQueryModel* ticket::afficher_ticket()
{
    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("SELECT * FROM ticket");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Id_res "));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Idt"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("tp"));


    return model;
}


void res::on_supprimer_ticket_clicked()
{
    QString ids = ui->supprimer_ticket_2->text();
    bool test = tmpticket.supprimer_ticket(ids);

    if(test)
    {
        ui->table_ticket->setModel(tmpticket.afficher_ticket());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un ticket"),
                        QObject::tr("ticket supprimé.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

        }
        else
            QMessageBox::critical(nullptr, QObject::tr("Supprimer un ticket"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);


    }



void res::on_chercher_modif_ticket_clicked()
{

    QString Idt = ui->chercher_res_2->text();

        ui->table_Re_ticket->setModel(tmpticket.afficher_Re_ticket(Idt));//refresh

}


void res::on_modifier_ticket_clicked()
{


        QString Id_res = ui->modifier_id_2->text();
        QString Idt = ui->modifier_idt->text();
        QString tp = ui->modifier_tp->text();


    bool test=tmpticket.modifier_ticket(Id_res,Idt,tp);


    if (test)
      {
        ui->table_ticket->setModel(tmpticket.afficher_ticket());//refresh
        ui->table_Re_ticket->setModel(tmpticket.afficher_Re_ticket(Idt));//refresh

    QMessageBox::information(nullptr, QObject::tr("modifier un ticket"),
                    QObject::tr("ticket modifie.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("modifier un ticket"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}


void res::on_tri_asc_ticket_clicked()
{
    ui->table_ticket->setModel(tmpticket.afficher_tri_IDt());

}

void res::on_tri_desc_ticket_clicked()
{
    ui->table_ticket->setModel(tmpticket.afficher_tri_IDt_DESC());
}

void res::on_pushButton_clicked()
{
    QString Idt = ui->combo_Idt_2->currentText();
    QString Id_res = ui->combo_Id_res_2->currentText();


    bool test=tmpticket.affecter_ticket(Idt,Id_res);

    if(test)
    {
        ui->table_ticket->setModel(tmpticket.afficher_ticket());
        QMessageBox::information(nullptr, QObject::tr("Affecter un ticket"),QObject::tr("ticket affecté.\n""Click cancel to exit."),QMessageBox::Cancel);
    }

else
    QMessageBox::critical(nullptr, QObject::tr("Affecter un ticket"),
                QObject::tr("Erreur !.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);
}



void res::on_chercher_res_2_textChanged(const QString &arg1)
{
      ui->table_Re_ticket->setModel(tmpticket.afficher_dyna_ticket(arg1));
}

void res::on_chercher_res_textChanged(const QString &arg1)
{
      ui->table_Re_res->setModel(tmpreservation.afficher_dyna_reservation(arg1));
}

void res::sendMail()
{
    Smtp* smtp = new Smtp(ui->uname_3->text(), ui->paswd_3->text(), ui->server_3->text(), ui->port_3->text().toInt());
    connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));
    smtp->sendMail(ui->uname_3->text(), ui->rcpt_3->text() , ui->subject_3->text(),ui->msg_3->toPlainText());
}


void res::mailSent(QString status)
{
    if(status == "Message sent")
        QMessageBox::warning(nullptr, tr( "Envoi Email" ), tr( "Email envoyé!\n\n" ) );
}
