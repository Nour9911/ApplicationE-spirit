#ifndef RESERVATION_H
#define RESERVATION_H
#include <QString>
#include <QSqlQueryModel>
#include <QSqlQuery>

class reservation
{
public:
    reservation();
    reservation(QString,QString,QString,QString,QString,QString);

    QString get_Id_reservation();
    QString get_Nom();
    QString get_Prenom();
    QString get_type_place();
    QString get_type_payment();
    QString get_payment();

    bool ajouter_reservation();
    QSqlQueryModel * afficher_reservation();
    bool supprimer_reservation(QString id);
    bool modifier_reservation(QString, QString, QString ,QString ,QString ,QString);
    bool chercher_reservation();
    QSqlQueryModel * afficher_Re_reservation(QString);
    QSqlQueryModel * afficher_tri_ID();
    QSqlQueryModel * afficher_tri_ID_DESC();
    QSqlQueryModel * afficher_dyna_reservation(QString rese);



private:
    QString  Id_reservation , Nom , Prenom , type_place , type_payment , payment;

};



#endif // RESERVATION_H
