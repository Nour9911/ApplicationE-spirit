#include "adherent.h"
#include "ui_adherent.h"
#include <QMessageBox>
#include "gestion_adh.h"
#include "gestion_cad.h"
#include "statistique.h"
#include <QSqlQuery>
#include <QDebug>
#include <QVariant>
#include <QPixmap>


adherent::adherent(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::adherent)

{
    ui->setupUi(this);
    this->setWindowTitle("GESTION DES ADHERENTS ET DES CADEAUX");
    this->setWindowIcon(QIcon("../projetc/e-spirit.png"));
    ui->table_adherent->setModel(tmpadherent.afficher_adherent());
    ui->table_cadeau_2->setModel(tmpcadeau.afficher_cadeau());
    QPixmap pix(":/new/prefix1/img/background.jpg");

    int w= ui->label_bk->width();
    int h= ui->label_bk->height();
    int w1= ui->label_bk_2->width();
    int h1= ui->label_bk_2->height();
    int w2= ui->label_bk_3->width();
    int h2= ui->label_bk_3->height();
    int w3= ui->label_bk_4->width();
    int h3= ui->label_bk_4->height();
    int w4= ui->label_bk_5->width();
    int h4= ui->label_bk_5->height();

    ui->label_bk->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
    ui->label_bk_2->setPixmap(pix.scaled(w1,h1,Qt::KeepAspectRatio));
    ui->label_bk_3->setPixmap(pix.scaled(w2,h2,Qt::KeepAspectRatio));
    ui->label_bk_4->setPixmap(pix.scaled(w3,h3,Qt::KeepAspectRatio));
    ui->label_bk_5->setPixmap(pix.scaled(w4,h4,Qt::KeepAspectRatio));



    QSqlQuery query;
    query.prepare("select id_adherent from adherent");
    if(query.exec())
        {
            while(query.next())
            {
                QString s = query.value(0).toString();//Récupère le résultat de la requête
                ui->combo_id_adh_2->addItem(s);
                ui->id_supp_combo->addItem(s);

            }
        }


    query.prepare("select id_cadeau from cadeau");
    if(query.exec())
        {
            while(query.next())
            {
                QString s = query.value(0).toString();//Récupère le résultat de la requête
                ui->combo_id_cad_2->addItem(s);
                ui->idCAD_supp_combo->addItem(s);
            }
        }


    /*query.prepare("select id_cadeau from cadeau");
    query.exec();
    int nb;
    while (query.next()) {
        nb = query.value(0).toInt();

    }

    query.prepare("select id_cadeau from cadeau where id_adh is NULL");
    query.exec();
    int nb1;
    while (query.next()) {
        nb1 = query.value(0).toInt();

    }*/


}



adherent::~adherent()
{
    delete ui;
}

void adherent::on_Ajouter_adherent_2_clicked()
{
    bool verif_id_adh,verif_nom,verif_prenom,verif_numero;

    bool verifID=false;
    bool verifNOM=false;
    bool verifPRENOM=false;
    bool verifNUM=false;


    verif_id_adh=true;
    verif_nom=true;
    verif_prenom=true;
    verif_numero=true;


    QString numbers = "0123456789";
    QString alphab = "azertyuiopqsdfghjklmwxcvbnéàçAZERTYUIOPQSDFGHJKLMWXCVBN";



    QString nom_adherent = ui->ajouter_nom_adherent_2->text();
    int v=0;
    for(int i = 0; i < nom_adherent.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(nom_adherent[i] == numbers[j]){
                           v = v +1;
                      }
                      if (v == 0)
                                              verifNOM = true;
                      else if(v != 0)
                    verifNOM = false;
                  }
                  if(verifNOM == false ){
                      verif_nom = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur ! nom ne doit pas contenir des nombres.\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }






    QString id_adherent = ui->ajouter_id_adherent_2->text();
    for(int i = 0; i < id_adherent.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(id_adherent[i] == numbers[j]){
                          verifID = true;
                      }
                  }
                  if(verifID == false ){
                      verif_id_adh = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur identifiant invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }






    QString prenom_adherent = ui->ajouter_prenom_adherent_2->text();
    for(int i = 0; i < prenom_adherent.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(prenom_adherent[i] == numbers[j]){
                          v = v +1;

                      }
                      if (v == 0)
                          verifPRENOM = true;
                      else if(v != 0)
                    verifPRENOM = false;
                  }
                  if(verifPRENOM == false ){
                      verif_prenom = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur ! prenom ne doit pas contenir des nombres.\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }


    QString numero_adherent = ui->ajouter_numero_adherent_2->text();
    for(int i = 0; i < numero_adherent.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(numero_adherent[i] == numbers[j]){
                          verifNUM = true;
                      }
                  }
                  if(verifNUM == false ){
                      verif_numero = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur numero invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }



    QString email_adherent = ui->ajouter_email_adherent_2->text();
    QString nombre_pts_adherent = ui->Ajouter_nombrepts_adherent_2->text();
    QString date_ajout_adh=ui->ajout_date_ajout->date().toString();


    if((verif_id_adh == true)&&(verif_nom == true) && (verif_prenom == true)&&(verif_numero == true)){
    gestion_adh ga(nom_adherent,id_adherent,prenom_adherent,numero_adherent,email_adherent,nombre_pts_adherent,date_ajout_adh);
    bool test=ga.ajouter_adherent();

    if(test)
    {
        ui->table_adherent->setModel(tmpadherent.afficher_adherent());
        ui->combo_id_adh_2->setModel(tmpcadeau.refresh_id_adh());
        ui->id_supp_combo->setModel(tmpcadeau.refresh_id_adh());
        QMessageBox::information(nullptr, QObject::tr("Ajouter un adherent"),QObject::tr("Adherent ajoutee.\n""Click cancel to exit."),QMessageBox::Cancel);
    }
    }

}


QSqlQueryModel * gestion_adh::afficher_adherent()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("SELECT * FROM adherent");


    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Nom "));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("ID"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Numero"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("Email"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("Points"));
    model->setHeaderData(6, Qt::Horizontal, QObject::tr("Date ajout"));

    return model;
}


void adherent::on_supprimer_adherent_3_clicked()
{

    QString id_adh = ui->id_supp_combo->currentText();


    bool test=tmpadherent.supprimer_adherent(id_adh);

    if(test)
    {

        ui->table_adherent->setModel(tmpadherent.afficher_adherent());
        ui->combo_id_adh_2->setModel(tmpcadeau.refresh_id_adh());
        ui->id_supp_combo->setModel(tmpcadeau.refresh_id_adh());
        QMessageBox::information(nullptr, QObject::tr("Suppression d'un adhérent"),QObject::tr("Adhérent supprimer.\n""Click cancel to exit."),QMessageBox::Cancel);
    }

else
    QMessageBox::critical(nullptr, QObject::tr("Suppression d'un adhérent"),
                QObject::tr("Erreur !.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

}




void adherent::on_Ajouter_cadeau_2_clicked()
{
    bool verif_id_cad;
    bool verifIDCAD=false;
    verif_id_cad=true;
    QString numbers = "0123456789";


    QString id_cadeau = ui->Ajouter_id_cadeau_2->text();
    for(int i = 0; i < id_cadeau.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(id_cadeau[i] == numbers[j]){
                          verifIDCAD = true;
                      }
                  }
                  if(verifIDCAD == false ){
                      verif_id_cad = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur identifiant invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }


    QString nom_cadeau = ui->ajouter_nom_cadeau_2->text();
    QString nb_pts_cadeau = ui->Ajouter_nombrepts_cadeau_2->text();
    QString id_adh;

    if(verif_id_cad == true) {
    gestion_cad gc(id_cadeau,nom_cadeau,nb_pts_cadeau,id_adh);
    bool test=gc.ajouter_cadeau();

    if(test)
    {
        ui->combo_id_cad_2->setModel(tmpcadeau.refresh_id_cad());
        ui->idCAD_supp_combo->setModel(tmpcadeau.refresh_id_cad());
        ui->table_cadeau_2->setModel(tmpcadeau.afficher_cadeau());
        QMessageBox::information(nullptr, QObject::tr("Ajouter un cadeau"),QObject::tr("Cadeau ajoutee.\n""Click cancel to exit."),QMessageBox::Cancel);
    }
}
}



QSqlQueryModel * gestion_cad::afficher_cadeau()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("SELECT * FROM cadeau");


    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Identifiant"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Points"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Id adherent"));

    return model;
}

void adherent::on_supprimer_cadeau_2_clicked()
{

    QString id_cadeau = ui->idCAD_supp_combo->currentText();
    bool test = tmpcadeau.supprimer_cadeau(id_cadeau);

    if(test)
    {
        ui->table_cadeau_2->setModel(tmpcadeau.afficher_cadeau());//refresh
        ui->combo_id_cad_2->setModel(tmpcadeau.refresh_id_cad());
        ui->idCAD_supp_combo->setModel(tmpcadeau.refresh_id_cad());
        QMessageBox::information(nullptr, QObject::tr("Supprimer un cadeau"),
                        QObject::tr("Cadeau supprimé.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

        }
        else
            QMessageBox::critical(nullptr, QObject::tr("Supprimer un cadeau"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);
}




void adherent::on_chercher_modif_adherent_clicked()
{

    QString id_adherent = ui->chercher_adherent->text();

        ui->table_Re_adherent->setModel(tmpadherent.afficher_Re_adherent(id_adherent));//refresh

}


void adherent::on_modifier_adherent_clicked()
{


        QString nom_adherent = ui->modifier_nom_adherent->text();
        QString id_adherent = ui->modifier_id_adherent->text();
        QString prenom_adherent = ui->modifier_prenom_adherent->text();
        QString numero_adherent = ui->modifier_numero_adherent->text();
        QString email_adherent = ui->modifier_email_adherent->text();
        QString nombre_pts_adherent= ui->modifier_pts_adherent->text();

    bool test=tmpadherent.modifier_adherent(nom_adherent,id_adherent,prenom_adherent,numero_adherent,email_adherent,nombre_pts_adherent);


    if (test)
      {
        ui->table_adherent->setModel(tmpadherent.afficher_adherent());//refresh
        ui->table_Re_adherent->setModel(tmpadherent.afficher_Re_adherent(id_adherent));//refresh

    QMessageBox::information(nullptr, QObject::tr("modifier un adherent"),
                    QObject::tr("Adhérent modifier.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("modifier un adherent"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}

void adherent::on_modifier_cadeau_clicked()
{

    QString id_cadeau = ui->modifier_id_cadeau->text();
    QString nom_cadeau = ui->modifier_nom_cadeau->text();
    QString nb_pts_cadeau = ui->modifier_pts_cadeau->text();
    QString id_adh;

bool test=tmpcadeau.modifier_cadeau(id_cadeau,nom_cadeau,nb_pts_cadeau,id_adh);


if (test)
  {

    ui->table_cadeau_2->setModel(tmpcadeau.afficher_cadeau());//refresh
    ui->table_Re_cadeau->setModel(tmpcadeau.afficher_Re_cadeau(id_cadeau));


QMessageBox::information(nullptr, QObject::tr("modifier un cadeau"),
                QObject::tr("Cadeau modifier.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

}
else
    QMessageBox::critical(nullptr, QObject::tr("modifier un cadeau"),
                QObject::tr("Erreur !.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

}

void adherent::on_chercher_cadeau_clicked()
{

    QString id_cadeau = ui->recherche_cadeau_id->text();

    ui->table_Re_cadeau->setModel(tmpcadeau.afficher_Re_cadeau(id_cadeau));//refresh

}


void adherent::on_tri_asc_clicked()
{
    ui->table_adherent->setModel(tmpadherent.afficher_tri_ID());

}

void adherent::on_tri_desc_clicked()
{
    ui->table_adherent->setModel(tmpadherent.afficher_tri_ID_DESC());
}

void adherent::on_tri_asc_cad_clicked()
{
    ui->table_cadeau_2->setModel(tmpcadeau.afficher_tri_CAD());
}

void adherent::on_tri_desc_cad_clicked()
{
    ui->table_cadeau_2->setModel(tmpcadeau.afficher_tri_CAD_DESC());
}



void adherent::on_affecter_cadeau_adh_clicked()
{
    QString id_cadeau = ui->combo_id_cad_2->currentText();
    QString id_adh = ui->combo_id_adh_2->currentText();


    bool test=tmpcadeau.affecter_cad(id_cadeau,id_adh);

    if(test)
    {
        ui->table_cadeau_2->setModel(tmpcadeau.afficher_cadeau());
        QMessageBox::information(nullptr, QObject::tr("Affecter un cadeau"),QObject::tr("Cadeau affecter.\n""Click cancel to exit."),QMessageBox::Cancel);
    }

else
    QMessageBox::critical(nullptr, QObject::tr("Affecter un cadeau"),
                QObject::tr("Erreur !.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);
}

void adherent::on_statistique_clicked()
{


}
