#include "ticket.h"
#include <QDebug>
#include <QVariant>
#include <QSqlQuery>

ticket::ticket()
{
  Id_res="";
  Idt="";
  tp="";
}

ticket::ticket( QString Id_res, QString Idt, QString tp)
{
    this->Id_res=Id_res;
    this->Idt=Idt;
    this->tp=tp;
}

QString ticket::get_Id_res(){return Id_res;}
QString ticket::get_Idt(){return Idt;}
QString ticket::get_tp(){return tp;}


bool ticket::ajouter_ticket()
{
    QSqlQuery query;
    query.prepare("INSERT INTO ticket (Id_res, Idt, tp)"
                  "VALUES (:Id_res, :Idt, :tp)");


    query.bindValue(":Id_res",Id_res);
    query.bindValue(":Idt",Idt);
    query.bindValue(":tp",tp);


    return query.exec();
}

bool ticket::supprimer_ticket(QString ids)
{
    QSqlQuery query;
    query.prepare("DELETE FROM ticket WHERE Idt = :ids ");
    query.bindValue(":ids",ids);

    return  query.exec();
}

bool ticket::modifier_ticket(QString Id_res, QString Idt, QString tp)
{
    QSqlQuery query;


        query.prepare("UPDATE ticket SET Id_res=:Id_res, tp=:tp WHERE Idt=:Idt");

        query.bindValue(":Id_res", Id_res);

        query.bindValue(":tp", tp);
        query.bindValue(":Idt", Idt);


        return    query.exec();
}






QSqlQueryModel * ticket::afficher_Re_ticket(QString val)
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->
            setQuery("select * from ticket where Idt= '"+val+"'") ;


    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Id_res "));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Idt"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("tp"));


    return model;
}
bool ticket::chercher_ticket()
{
   /* QSqlQuery query;
    query.prepare("SELECT FROM ticket WHERE Idt = :Idt ");
    query.bindValue(":Idt", Idt);

    return  query.exec();*/
 }

QSqlQueryModel * ticket:: afficher_tri_IDt()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from ticket order by Idt");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("Id_res "));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Idt"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("tp"));

    return model;
}

QSqlQueryModel * ticket:: afficher_tri_IDt_DESC()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from ticket order by Idt desc ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("Id_res "));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Idt"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("tp"));

    return model;
}

bool ticket::affecter_ticket(QString Idt, QString Id_res)
{
    QSqlQuery query;


        query.prepare("UPDATE ticket SET Id_res=:Id_res WHERE Idt=:Idt");

        query.bindValue(":Idt", Idt);
        query.bindValue(":Id_res", Id_res);



        return    query.exec();
}

QSqlQueryModel * ticket:: refresh_Id_res()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select Id_reservation from reservation order by Id_reservation asc ");

    return model;
}

QSqlQueryModel * ticket:: refresh_Idt()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select Idt from ticket order by Idt asc ");

    return model;
}

QSqlQueryModel * ticket::afficher_dyna_ticket(QString tic)
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->
            setQuery("select * from ticket where (ticket.Idt LIKE '"+tic+"%')");


    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Id_res "));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Idt"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("tp"));
    return model;
}
