#include "reservation.h"
#include <QDebug>
#include <QVariant>
#include <QSqlQuery>

reservation::reservation()
{
  Id_reservation="";
  Nom="";
  Prenom="";
  type_place="";
  type_payment="";
  payment="";
}

reservation::reservation( QString Id_reservation, QString Nom, QString Prenom, QString type_place, QString type_payment, QString payment)
{
    this->Id_reservation=Id_reservation;
    this->Nom=Nom;
    this->Prenom=Prenom;
    this->type_place=type_place;
    this->type_payment=type_payment;
    this->payment=payment;
}

QString reservation::get_Id_reservation(){return Id_reservation;}
QString reservation::get_Nom(){return Nom;}
QString reservation::get_Prenom(){return Prenom;}
QString reservation::get_type_place(){return type_place;}
QString reservation::get_type_payment(){return type_payment;}
QString reservation::get_payment(){return payment;}

bool reservation::ajouter_reservation()
{
    QSqlQuery query;
    query.prepare("INSERT INTO reservation (Id_reservation, Nom, Prenom, type_place, type_payment, payment)"
                  "VALUES (:Id_reservation, :Nom, :Prenom, :type_place, :type_payment, :payment)");


    query.bindValue(":Id_reservation",Id_reservation);
    query.bindValue(":Nom",Nom);
    query.bindValue(":Prenom",Prenom);
    query.bindValue(":type_place",type_place);
    query.bindValue(":type_payment",type_payment);
    query.bindValue(":payment",payment);

    return query.exec();
}

bool reservation::supprimer_reservation(QString id)
{
    QSqlQuery query;
    query.prepare("DELETE FROM reservation WHERE Id_reservation = :id ");
    query.bindValue(":id",id);

    return  query.exec();
}

bool reservation::modifier_reservation(QString Id_reservation, QString Nom, QString Prenom , QString type_place ,QString type_payment , QString payment)
{
    QSqlQuery query;


        query.prepare("UPDATE reservation SET Nom=:Nom , Prenom=:Prenom, type_place=:type_place, type_payment=:type_payment , payment= :payment  WHERE Id_reservation=:Id_reservation");

        query.bindValue(":Id_reservation", Id_reservation);
        query.bindValue(":Nom", Nom);
        query.bindValue(":Prenom", Prenom);
        query.bindValue(":type_place", type_place);
        query.bindValue(":type_payment", type_payment);
        query.bindValue(":payment", payment);


        return    query.exec();
}






QSqlQueryModel * reservation::afficher_Re_reservation(QString val)
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->
            setQuery("select * from reservation where Id_reservation= '"+val+"'") ;


    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Id_reservation "));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prenom"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("type_place"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("type_payment"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("payment"));

    return model;
}
bool reservation::chercher_reservation()
{
   /* QSqlQuery query;
    query.prepare("SELECT FROM reservation WHERE Id_reservation = :Id_Rreservation ");
    query.bindValue(":Id_reservation", Id_Rreservation);

    return  query.exec();*/
 }

QSqlQueryModel * reservation:: afficher_tri_ID()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from reservation order by Id_reservation");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("Id_reservation "));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prenom"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("type_place"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("type_payment"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("payment"));
    return model;
}

QSqlQueryModel * reservation:: afficher_tri_ID_DESC()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from reservation order by Id_reservation desc ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("Id_reservation "));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("type_place"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("type_payment"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("payment"));
    return model;
}

QSqlQueryModel * reservation::afficher_dyna_reservation(QString rese)
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->
            setQuery("select * from reservation where (reservation.Id_reservation LIKE '"+rese+"%')");


    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Id_reservation "));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("type_place"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("type_payment"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("payment"));
    return model;
}
