/********************************************************************************
** Form generated from reading UI file 'sponsor.ui'
**
** Created by: Qt User Interface Compiler version 5.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SPONSOR_H
#define UI_SPONSOR_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_sponsor
{
public:
    QVBoxLayout *verticalLayout;
    QTabWidget *tabWidget_2;
    QWidget *tab_Supprimer;
    QLabel *label_18;
    QLabel *labelB_2;
    QTabWidget *tabWidget;
    QWidget *tab;
    QLabel *label;
    QLineEdit *lineEdit_id;
    QPushButton *pb_ajouter;
    QLineEdit *lineEdit_dons;
    QLineEdit *lineEdit_nom_spnsor;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_24;
    QLabel *label_9;
    QDateEdit *lineEdit_date;
    QWidget *tab_2;
    QTableView *tabSPON;
    QLabel *label_25;
    QPushButton *pdf;
    QRadioButton *radioButton_6;
    QPushButton *voir_3;
    QLabel *label_47;
    QComboBox *comboBox;
    QPushButton *ajouterr;
    QRadioButton *radioButton_5;
    QWidget *tab_3;
    QLineEdit *lineEdit_id_s;
    QLabel *label_4;
    QPushButton *pb_supprimer;
    QLabel *label_23;
    QWidget *tab_6;
    QLineEdit *lineEdit_id_22;
    QLineEdit *lineEdit_nom_22;
    QLineEdit *lineEdit_dons_22;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_5;
    QPushButton *update;
    QLabel *label_22;
    QLabel *label_10;
    QDateEdit *lineEdit_date_22;
    QWidget *tab_7;
    QLineEdit *lineEdit_nom_spnsor_22;
    QPushButton *search;
    QLabel *label_8;
    QLabel *label_21;
    QTableView *tabSPON_2;
    QWidget *tab_Ajouter;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *label_17;
    QLabel *labelB_4;
    QTabWidget *tabWidget_3;
    QWidget *tab_4;
    QLabel *label_31;
    QLabel *label_32;
    QLabel *label_33;
    QLineEdit *lineEdit_id_p;
    QPushButton *pb_ajouterp;
    QLineEdit *lineEdit_prix;
    QLineEdit *lineEdit_duree;
    QLineEdit *lineEdit_nom;
    QLabel *label_34;
    QLabel *label_35;
    QLabel *label_36;
    QLabel *label_37;
    QLineEdit *lineEdit_date_f;
    QDateEdit *lineEdit_date_d;
    QWidget *tab_5;
    QTableView *tabpub;
    QLabel *label_39;
    QPushButton *pdfp;
    QRadioButton *radioButton_5p;
    QRadioButton *radioButton_6p;
    QPushButton *voir_2;
    QLabel *label_4r_2;
    QComboBox *comboBox_2;
    QPushButton *ajouterrr;
    QWidget *tab_8;
    QLineEdit *lineEdit_id_3;
    QLabel *label_40;
    QPushButton *pb_supprimerp;
    QLabel *label_41;
    QWidget *tab_9;
    QLineEdit *lineEdit_id_4;
    QLineEdit *lineEdit_nom_4;
    QLineEdit *lineEdit_duree_2;
    QLineEdit *lineEdit_prix_2;
    QPushButton *updatep;
    QLabel *label_48;
    QLabel *label_38;
    QLabel *label_42;
    QLabel *label_43;
    QLabel *label_44;
    QLabel *label_52;
    QLabel *label_53;
    QLineEdit *lineEdit_date_f_2;
    QDateEdit *lineEdit_date_d_2;
    QWidget *tab_10;
    QLineEdit *lineEdit_cin_2;
    QPushButton *searchp;
    QLabel *label_50;
    QLabel *label_51;
    QTableView *tabpub_2;
    QWidget *tab_Afficher;
    QLabel *labelB_5;
    QTabWidget *tabWidget_4;
    QWidget *tab_12;
    QTableView *tabrev;
    QLabel *label_57;
    QPushButton *pdfr;
    QPushButton *searchr_2;
    QPushButton *voir;
    QWidget *tab_15;
    QLineEdit *lineEdit_cin_3;
    QLabel *label_67;
    QLabel *label_68;
    QTableView *tabpub_4;
    QPushButton *searchr;

    void setupUi(QDialog *sponsor)
    {
        if (sponsor->objectName().isEmpty())
            sponsor->setObjectName(QStringLiteral("sponsor"));
        sponsor->resize(678, 514);
        verticalLayout = new QVBoxLayout(sponsor);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        tabWidget_2 = new QTabWidget(sponsor);
        tabWidget_2->setObjectName(QStringLiteral("tabWidget_2"));
        QFont font;
        font.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font.setPointSize(10);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        tabWidget_2->setFont(font);
        tabWidget_2->setMouseTracking(false);
        tabWidget_2->setTabletTracking(false);
        tabWidget_2->setAcceptDrops(false);
        tabWidget_2->setAutoFillBackground(false);
        tabWidget_2->setStyleSheet(QStringLiteral("font: 10pt \"MS Shell Dlg 2\";"));
        tabWidget_2->setTabPosition(QTabWidget::North);
        tabWidget_2->setTabShape(QTabWidget::Triangular);
        tabWidget_2->setElideMode(Qt::ElideNone);
        tabWidget_2->setDocumentMode(true);
        tabWidget_2->setTabsClosable(false);
        tabWidget_2->setMovable(false);
        tabWidget_2->setTabBarAutoHide(false);
        tab_Supprimer = new QWidget();
        tab_Supprimer->setObjectName(QStringLiteral("tab_Supprimer"));
        label_18 = new QLabel(tab_Supprimer);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(120, 100, 41, 16));
        labelB_2 = new QLabel(tab_Supprimer);
        labelB_2->setObjectName(QStringLiteral("labelB_2"));
        labelB_2->setGeometry(QRect(0, 0, 721, 501));
        labelB_2->setStyleSheet(QLatin1String("\n"
"background-color: rgb(170, 0, 0);"));
        tabWidget = new QTabWidget(tab_Supprimer);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(50, 30, 561, 361));
        QFont font1;
        font1.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font1.setPointSize(10);
        font1.setBold(false);
        font1.setWeight(50);
        tabWidget->setFont(font1);
        tabWidget->setLayoutDirection(Qt::LeftToRight);
        tabWidget->setAutoFillBackground(false);
        tabWidget->setStyleSheet(QStringLiteral(""));
        tabWidget->setTabShape(QTabWidget::Rounded);
        tabWidget->setDocumentMode(true);
        tabWidget->setTabsClosable(false);
        tabWidget->setMovable(false);
        tabWidget->setTabBarAutoHide(false);
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        label = new QLabel(tab);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 30, 101, 16));
        label->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        lineEdit_id = new QLineEdit(tab);
        lineEdit_id->setObjectName(QStringLiteral("lineEdit_id"));
        lineEdit_id->setGeometry(QRect(160, 30, 113, 20));
        lineEdit_id->setAcceptDrops(true);
        lineEdit_id->setStyleSheet(QLatin1String("color: white;\n"
"                                         \n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        lineEdit_id->setFrame(true);
        pb_ajouter = new QPushButton(tab);
        pb_ajouter->setObjectName(QStringLiteral("pb_ajouter"));
        pb_ajouter->setGeometry(QRect(380, 120, 161, 31));
        pb_ajouter->setAcceptDrops(false);
        pb_ajouter->setStyleSheet(QLatin1String("\n"
"border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);\n"
""));
        pb_ajouter->setCheckable(false);
        pb_ajouter->setAutoRepeat(false);
        pb_ajouter->setAutoExclusive(false);
        pb_ajouter->setAutoDefault(true);
        pb_ajouter->setFlat(false);
        lineEdit_dons = new QLineEdit(tab);
        lineEdit_dons->setObjectName(QStringLiteral("lineEdit_dons"));
        lineEdit_dons->setGeometry(QRect(160, 150, 113, 20));
        lineEdit_dons->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        lineEdit_nom_spnsor = new QLineEdit(tab);
        lineEdit_nom_spnsor->setObjectName(QStringLiteral("lineEdit_nom_spnsor"));
        lineEdit_nom_spnsor->setGeometry(QRect(160, 90, 113, 20));
        lineEdit_nom_spnsor->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        label_6 = new QLabel(tab);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(10, 150, 141, 20));
        label_6->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
""));
        label_7 = new QLabel(tab);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(20, 90, 81, 16));
        label_7->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
""));
        label_24 = new QLabel(tab);
        label_24->setObjectName(QStringLiteral("label_24"));
        label_24->setGeometry(QRect(0, 0, 631, 451));
        label_24->setFont(font);
        label_24->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        label_9 = new QLabel(tab);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(10, 220, 81, 16));
        label_9->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
""));
        lineEdit_date = new QDateEdit(tab);
        lineEdit_date->setObjectName(QStringLiteral("lineEdit_date"));
        lineEdit_date->setGeometry(QRect(120, 220, 211, 22));
        lineEdit_date->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
""));
        lineEdit_date->setMaximumDateTime(QDateTime(QDate(2020, 12, 31), QTime(23, 59, 59)));
        lineEdit_date->setMinimumDateTime(QDateTime(QDate(2020, 1, 1), QTime(0, 0, 0)));
        lineEdit_date->setCalendarPopup(true);
        lineEdit_date->setTimeSpec(Qt::LocalTime);
        lineEdit_date->setDate(QDate(2020, 4, 25));
        tabWidget->addTab(tab, QString());
        label_24->raise();
        label->raise();
        lineEdit_id->raise();
        pb_ajouter->raise();
        lineEdit_dons->raise();
        lineEdit_nom_spnsor->raise();
        label_6->raise();
        label_7->raise();
        label_9->raise();
        lineEdit_date->raise();
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        tabSPON = new QTableView(tab_2);
        tabSPON->setObjectName(QStringLiteral("tabSPON"));
        tabSPON->setEnabled(true);
        tabSPON->setGeometry(QRect(40, 40, 511, 231));
        tabSPON->setTabletTracking(false);
        tabSPON->setFrameShape(QFrame::NoFrame);
        tabSPON->setFrameShadow(QFrame::Raised);
        tabSPON->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        tabSPON->setSizeAdjustPolicy(QAbstractScrollArea::AdjustIgnored);
        tabSPON->setDragEnabled(false);
        tabSPON->setVerticalScrollMode(QAbstractItemView::ScrollPerItem);
        tabSPON->setGridStyle(Qt::SolidLine);
        tabSPON->setSortingEnabled(false);
        label_25 = new QLabel(tab_2);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setGeometry(QRect(0, 0, 631, 451));
        label_25->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        pdf = new QPushButton(tab_2);
        pdf->setObjectName(QStringLiteral("pdf"));
        pdf->setGeometry(QRect(480, 270, 75, 23));
        pdf->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        radioButton_6 = new QRadioButton(tab_2);
        radioButton_6->setObjectName(QStringLiteral("radioButton_6"));
        radioButton_6->setGeometry(QRect(460, 20, 91, 20));
        radioButton_6->setStyleSheet(QStringLiteral("background-color: rgb(170, 0, 0);"));
        voir_3 = new QPushButton(tab_2);
        voir_3->setObjectName(QStringLiteral("voir_3"));
        voir_3->setGeometry(QRect(20, 10, 141, 31));
        voir_3->setCursor(QCursor(Qt::ClosedHandCursor));
        voir_3->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        label_47 = new QLabel(tab_2);
        label_47->setObjectName(QStringLiteral("label_47"));
        label_47->setGeometry(QRect(0, 270, 261, 51));
        label_47->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        comboBox = new QComboBox(tab_2);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(280, 290, 41, 21));
        comboBox->setStyleSheet(QStringLiteral("border-color: rgb(170, 0, 0);"));
        ajouterr = new QPushButton(tab_2);
        ajouterr->setObjectName(QStringLiteral("ajouterr"));
        ajouterr->setGeometry(QRect(330, 310, 111, 21));
        ajouterr->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        radioButton_5 = new QRadioButton(tab_2);
        radioButton_5->setObjectName(QStringLiteral("radioButton_5"));
        radioButton_5->setGeometry(QRect(350, 20, 91, 20));
        radioButton_5->setTabletTracking(false);
        radioButton_5->setFocusPolicy(Qt::StrongFocus);
        radioButton_5->setContextMenuPolicy(Qt::DefaultContextMenu);
        radioButton_5->setAutoFillBackground(false);
        radioButton_5->setStyleSheet(QStringLiteral("background-color: rgb(170, 0, 0);"));
        tabWidget->addTab(tab_2, QString());
        label_25->raise();
        tabSPON->raise();
        pdf->raise();
        radioButton_6->raise();
        voir_3->raise();
        label_47->raise();
        comboBox->raise();
        ajouterr->raise();
        radioButton_5->raise();
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        lineEdit_id_s = new QLineEdit(tab_3);
        lineEdit_id_s->setObjectName(QStringLiteral("lineEdit_id_s"));
        lineEdit_id_s->setGeometry(QRect(300, 80, 141, 21));
        lineEdit_id_s->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        label_4 = new QLabel(tab_3);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(40, 40, 241, 20));
        label_4->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        pb_supprimer = new QPushButton(tab_3);
        pb_supprimer->setObjectName(QStringLiteral("pb_supprimer"));
        pb_supprimer->setGeometry(QRect(210, 140, 171, 23));
        pb_supprimer->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        label_23 = new QLabel(tab_3);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(-10, 0, 761, 451));
        label_23->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        tabWidget->addTab(tab_3, QString());
        label_23->raise();
        lineEdit_id_s->raise();
        label_4->raise();
        pb_supprimer->raise();
        tab_6 = new QWidget();
        tab_6->setObjectName(QStringLiteral("tab_6"));
        lineEdit_id_22 = new QLineEdit(tab_6);
        lineEdit_id_22->setObjectName(QStringLiteral("lineEdit_id_22"));
        lineEdit_id_22->setGeometry(QRect(170, 30, 113, 20));
        lineEdit_id_22->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        lineEdit_nom_22 = new QLineEdit(tab_6);
        lineEdit_nom_22->setObjectName(QStringLiteral("lineEdit_nom_22"));
        lineEdit_nom_22->setGeometry(QRect(170, 90, 113, 20));
        lineEdit_nom_22->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        lineEdit_dons_22 = new QLineEdit(tab_6);
        lineEdit_dons_22->setObjectName(QStringLiteral("lineEdit_dons_22"));
        lineEdit_dons_22->setGeometry(QRect(170, 150, 113, 20));
        lineEdit_dons_22->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        label_2 = new QLabel(tab_6);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(20, 30, 61, 16));
        label_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_3 = new QLabel(tab_6);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(20, 90, 81, 16));
        label_3->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
""));
        label_5 = new QLabel(tab_6);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(20, 150, 131, 16));
        label_5->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        update = new QPushButton(tab_6);
        update->setObjectName(QStringLiteral("update"));
        update->setGeometry(QRect(400, 90, 75, 23));
        update->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        label_22 = new QLabel(tab_6);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(0, 0, 761, 451));
        label_22->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        label_10 = new QLabel(tab_6);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(20, 220, 81, 16));
        label_10->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        lineEdit_date_22 = new QDateEdit(tab_6);
        lineEdit_date_22->setObjectName(QStringLiteral("lineEdit_date_22"));
        lineEdit_date_22->setGeometry(QRect(130, 220, 211, 22));
        lineEdit_date_22->setMaximumDateTime(QDateTime(QDate(2020, 12, 31), QTime(23, 59, 59)));
        lineEdit_date_22->setMinimumDateTime(QDateTime(QDate(2020, 1, 1), QTime(0, 0, 0)));
        lineEdit_date_22->setMinimumDate(QDate(2020, 1, 1));
        lineEdit_date_22->setCurrentSection(QDateTimeEdit::DaySection);
        lineEdit_date_22->setCalendarPopup(true);
        lineEdit_date_22->setTimeSpec(Qt::LocalTime);
        lineEdit_date_22->setDate(QDate(2020, 4, 25));
        tabWidget->addTab(tab_6, QString());
        label_22->raise();
        lineEdit_id_22->raise();
        lineEdit_nom_22->raise();
        lineEdit_dons_22->raise();
        label_2->raise();
        label_3->raise();
        label_5->raise();
        update->raise();
        label_10->raise();
        lineEdit_date_22->raise();
        tab_7 = new QWidget();
        tab_7->setObjectName(QStringLiteral("tab_7"));
        lineEdit_nom_spnsor_22 = new QLineEdit(tab_7);
        lineEdit_nom_spnsor_22->setObjectName(QStringLiteral("lineEdit_nom_spnsor_22"));
        lineEdit_nom_spnsor_22->setGeometry(QRect(300, 50, 113, 22));
        lineEdit_nom_spnsor_22->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        search = new QPushButton(tab_7);
        search->setObjectName(QStringLiteral("search"));
        search->setGeometry(QRect(420, 80, 121, 21));
        search->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        label_8 = new QLabel(tab_7);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(40, 20, 241, 20));
        label_8->setFont(font);
        label_8->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_21 = new QLabel(tab_7);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setGeometry(QRect(-10, 0, 761, 451));
        label_21->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        tabSPON_2 = new QTableView(tab_7);
        tabSPON_2->setObjectName(QStringLiteral("tabSPON_2"));
        tabSPON_2->setGeometry(QRect(60, 120, 461, 161));
        tabWidget->addTab(tab_7, QString());
        label_21->raise();
        lineEdit_nom_spnsor_22->raise();
        search->raise();
        label_8->raise();
        tabSPON_2->raise();
        QIcon icon;
        QString iconThemeName = QStringLiteral("m");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon = QIcon::fromTheme(iconThemeName);
        } else {
            icon.addFile(QStringLiteral("."), QSize(), QIcon::Normal, QIcon::Off);
        }
        tabWidget_2->addTab(tab_Supprimer, icon, QString());
        tab_Ajouter = new QWidget();
        tab_Ajouter->setObjectName(QStringLiteral("tab_Ajouter"));
        label_11 = new QLabel(tab_Ajouter);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(101, 115, 41, 51));
        label_12 = new QLabel(tab_Ajouter);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(120, 90, 55, 16));
        label_13 = new QLabel(tab_Ajouter);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(120, 210, 91, 16));
        label_14 = new QLabel(tab_Ajouter);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(120, 240, 71, 16));
        label_14->setFont(font);
        label_15 = new QLabel(tab_Ajouter);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(120, 60, 51, 16));
        label_16 = new QLabel(tab_Ajouter);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(120, 120, 55, 16));
        label_17 = new QLabel(tab_Ajouter);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(120, 180, 55, 16));
        labelB_4 = new QLabel(tab_Ajouter);
        labelB_4->setObjectName(QStringLiteral("labelB_4"));
        labelB_4->setGeometry(QRect(0, 0, 831, 571));
        labelB_4->setStyleSheet(QStringLiteral("background-color: rgb(170, 0, 0);"));
        tabWidget_3 = new QTabWidget(tab_Ajouter);
        tabWidget_3->setObjectName(QStringLiteral("tabWidget_3"));
        tabWidget_3->setGeometry(QRect(50, 40, 581, 361));
        tabWidget_3->setFont(font1);
        tabWidget_3->setAutoFillBackground(false);
        tabWidget_3->setStyleSheet(QStringLiteral(""));
        tabWidget_3->setDocumentMode(true);
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        label_31 = new QLabel(tab_4);
        label_31->setObjectName(QStringLiteral("label_31"));
        label_31->setGeometry(QRect(20, 30, 101, 16));
        label_31->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_32 = new QLabel(tab_4);
        label_32->setObjectName(QStringLiteral("label_32"));
        label_32->setGeometry(QRect(20, 200, 121, 21));
        label_32->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_33 = new QLabel(tab_4);
        label_33->setObjectName(QStringLiteral("label_33"));
        label_33->setGeometry(QRect(10, 240, 191, 41));
        label_33->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        lineEdit_id_p = new QLineEdit(tab_4);
        lineEdit_id_p->setObjectName(QStringLiteral("lineEdit_id_p"));
        lineEdit_id_p->setGeometry(QRect(230, 30, 113, 20));
        lineEdit_id_p->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        pb_ajouterp = new QPushButton(tab_4);
        pb_ajouterp->setObjectName(QStringLiteral("pb_ajouterp"));
        pb_ajouterp->setGeometry(QRect(410, 140, 141, 31));
        pb_ajouterp->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        lineEdit_prix = new QLineEdit(tab_4);
        lineEdit_prix->setObjectName(QStringLiteral("lineEdit_prix"));
        lineEdit_prix->setGeometry(QRect(240, 300, 113, 20));
        lineEdit_prix->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        lineEdit_duree = new QLineEdit(tab_4);
        lineEdit_duree->setObjectName(QStringLiteral("lineEdit_duree"));
        lineEdit_duree->setGeometry(QRect(230, 140, 113, 20));
        lineEdit_duree->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        lineEdit_nom = new QLineEdit(tab_4);
        lineEdit_nom->setObjectName(QStringLiteral("lineEdit_nom"));
        lineEdit_nom->setGeometry(QRect(230, 80, 113, 20));
        lineEdit_nom->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        label_34 = new QLabel(tab_4);
        label_34->setObjectName(QStringLiteral("label_34"));
        label_34->setGeometry(QRect(30, 300, 91, 16));
        label_34->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
""));
        label_35 = new QLabel(tab_4);
        label_35->setObjectName(QStringLiteral("label_35"));
        label_35->setGeometry(QRect(20, 130, 191, 41));
        label_35->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_36 = new QLabel(tab_4);
        label_36->setObjectName(QStringLiteral("label_36"));
        label_36->setGeometry(QRect(20, 80, 81, 16));
        label_36->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_37 = new QLabel(tab_4);
        label_37->setObjectName(QStringLiteral("label_37"));
        label_37->setGeometry(QRect(0, -10, 671, 461));
        label_37->setFont(font);
        label_37->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        lineEdit_date_f = new QLineEdit(tab_4);
        lineEdit_date_f->setObjectName(QStringLiteral("lineEdit_date_f"));
        lineEdit_date_f->setGeometry(QRect(230, 250, 131, 21));
        lineEdit_date_f->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        lineEdit_date_d = new QDateEdit(tab_4);
        lineEdit_date_d->setObjectName(QStringLiteral("lineEdit_date_d"));
        lineEdit_date_d->setGeometry(QRect(230, 200, 131, 22));
        lineEdit_date_d->setMaximumDateTime(QDateTime(QDate(2020, 12, 31), QTime(23, 59, 59)));
        lineEdit_date_d->setMinimumDateTime(QDateTime(QDate(2020, 1, 1), QTime(0, 0, 0)));
        lineEdit_date_d->setCurrentSection(QDateTimeEdit::DaySection);
        lineEdit_date_d->setCalendarPopup(true);
        lineEdit_date_d->setTimeSpec(Qt::LocalTime);
        lineEdit_date_d->setDate(QDate(2020, 4, 25));
        tabWidget_3->addTab(tab_4, QString());
        label_37->raise();
        label_31->raise();
        label_32->raise();
        label_33->raise();
        lineEdit_id_p->raise();
        pb_ajouterp->raise();
        label_34->raise();
        label_35->raise();
        label_36->raise();
        lineEdit_prix->raise();
        lineEdit_duree->raise();
        lineEdit_nom->raise();
        lineEdit_date_f->raise();
        lineEdit_date_d->raise();
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        tabpub = new QTableView(tab_5);
        tabpub->setObjectName(QStringLiteral("tabpub"));
        tabpub->setGeometry(QRect(0, 40, 571, 231));
        label_39 = new QLabel(tab_5);
        label_39->setObjectName(QStringLiteral("label_39"));
        label_39->setGeometry(QRect(0, 0, 631, 451));
        label_39->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        pdfp = new QPushButton(tab_5);
        pdfp->setObjectName(QStringLiteral("pdfp"));
        pdfp->setGeometry(QRect(500, 270, 75, 23));
        pdfp->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        radioButton_5p = new QRadioButton(tab_5);
        radioButton_5p->setObjectName(QStringLiteral("radioButton_5p"));
        radioButton_5p->setGeometry(QRect(380, 20, 91, 21));
        radioButton_5p->setStyleSheet(QStringLiteral("background-color: rgb(170, 0, 0);"));
        radioButton_6p = new QRadioButton(tab_5);
        radioButton_6p->setObjectName(QStringLiteral("radioButton_6p"));
        radioButton_6p->setGeometry(QRect(480, 20, 91, 20));
        radioButton_6p->setStyleSheet(QStringLiteral("background-color: rgb(170, 0, 0);"));
        voir_2 = new QPushButton(tab_5);
        voir_2->setObjectName(QStringLiteral("voir_2"));
        voir_2->setGeometry(QRect(0, 10, 131, 31));
        voir_2->setCursor(QCursor(Qt::ClosedHandCursor));
        voir_2->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        label_4r_2 = new QLabel(tab_5);
        label_4r_2->setObjectName(QStringLiteral("label_4r_2"));
        label_4r_2->setGeometry(QRect(10, 270, 251, 31));
        label_4r_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        comboBox_2 = new QComboBox(tab_5);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setGeometry(QRect(270, 280, 61, 21));
        ajouterrr = new QPushButton(tab_5);
        ajouterrr->setObjectName(QStringLiteral("ajouterrr"));
        ajouterrr->setGeometry(QRect(310, 310, 91, 21));
        ajouterrr->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        tabWidget_3->addTab(tab_5, QString());
        label_39->raise();
        pdfp->raise();
        tabpub->raise();
        radioButton_5p->raise();
        radioButton_6p->raise();
        voir_2->raise();
        label_4r_2->raise();
        comboBox_2->raise();
        ajouterrr->raise();
        tab_8 = new QWidget();
        tab_8->setObjectName(QStringLiteral("tab_8"));
        lineEdit_id_3 = new QLineEdit(tab_8);
        lineEdit_id_3->setObjectName(QStringLiteral("lineEdit_id_3"));
        lineEdit_id_3->setGeometry(QRect(280, 90, 151, 20));
        lineEdit_id_3->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        label_40 = new QLabel(tab_8);
        label_40->setObjectName(QStringLiteral("label_40"));
        label_40->setGeometry(QRect(90, 40, 241, 20));
        label_40->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        pb_supprimerp = new QPushButton(tab_8);
        pb_supprimerp->setObjectName(QStringLiteral("pb_supprimerp"));
        pb_supprimerp->setGeometry(QRect(380, 150, 131, 21));
        pb_supprimerp->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        label_41 = new QLabel(tab_8);
        label_41->setObjectName(QStringLiteral("label_41"));
        label_41->setGeometry(QRect(0, 0, 761, 451));
        label_41->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        tabWidget_3->addTab(tab_8, QString());
        label_41->raise();
        lineEdit_id_3->raise();
        label_40->raise();
        pb_supprimerp->raise();
        tab_9 = new QWidget();
        tab_9->setObjectName(QStringLiteral("tab_9"));
        lineEdit_id_4 = new QLineEdit(tab_9);
        lineEdit_id_4->setObjectName(QStringLiteral("lineEdit_id_4"));
        lineEdit_id_4->setGeometry(QRect(230, 30, 113, 20));
        lineEdit_id_4->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        lineEdit_nom_4 = new QLineEdit(tab_9);
        lineEdit_nom_4->setObjectName(QStringLiteral("lineEdit_nom_4"));
        lineEdit_nom_4->setGeometry(QRect(230, 80, 113, 20));
        lineEdit_nom_4->setStyleSheet(QLatin1String("color: white;\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;\n"
"background-color: rgb(89, 89, 89);\n"
""));
        lineEdit_duree_2 = new QLineEdit(tab_9);
        lineEdit_duree_2->setObjectName(QStringLiteral("lineEdit_duree_2"));
        lineEdit_duree_2->setGeometry(QRect(230, 130, 113, 20));
        lineEdit_duree_2->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        lineEdit_prix_2 = new QLineEdit(tab_9);
        lineEdit_prix_2->setObjectName(QStringLiteral("lineEdit_prix_2"));
        lineEdit_prix_2->setGeometry(QRect(230, 290, 113, 20));
        lineEdit_prix_2->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        updatep = new QPushButton(tab_9);
        updatep->setObjectName(QStringLiteral("updatep"));
        updatep->setGeometry(QRect(420, 130, 121, 31));
        updatep->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        label_48 = new QLabel(tab_9);
        label_48->setObjectName(QStringLiteral("label_48"));
        label_48->setGeometry(QRect(0, -20, 761, 451));
        label_48->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        label_38 = new QLabel(tab_9);
        label_38->setObjectName(QStringLiteral("label_38"));
        label_38->setGeometry(QRect(20, 30, 101, 16));
        label_38->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_42 = new QLabel(tab_9);
        label_42->setObjectName(QStringLiteral("label_42"));
        label_42->setGeometry(QRect(20, 80, 81, 16));
        label_42->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_43 = new QLabel(tab_9);
        label_43->setObjectName(QStringLiteral("label_43"));
        label_43->setGeometry(QRect(20, 120, 191, 41));
        label_43->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_44 = new QLabel(tab_9);
        label_44->setObjectName(QStringLiteral("label_44"));
        label_44->setGeometry(QRect(20, 170, 111, 41));
        label_44->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_52 = new QLabel(tab_9);
        label_52->setObjectName(QStringLiteral("label_52"));
        label_52->setGeometry(QRect(20, 240, 151, 20));
        label_52->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_53 = new QLabel(tab_9);
        label_53->setObjectName(QStringLiteral("label_53"));
        label_53->setGeometry(QRect(30, 290, 91, 16));
        label_53->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        lineEdit_date_f_2 = new QLineEdit(tab_9);
        lineEdit_date_f_2->setObjectName(QStringLiteral("lineEdit_date_f_2"));
        lineEdit_date_f_2->setGeometry(QRect(230, 240, 113, 20));
        lineEdit_date_f_2->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        lineEdit_date_d_2 = new QDateEdit(tab_9);
        lineEdit_date_d_2->setObjectName(QStringLiteral("lineEdit_date_d_2"));
        lineEdit_date_d_2->setGeometry(QRect(240, 190, 101, 22));
        lineEdit_date_d_2->setMaximumDateTime(QDateTime(QDate(2020, 12, 31), QTime(23, 59, 59)));
        lineEdit_date_d_2->setMinimumDateTime(QDateTime(QDate(2020, 1, 1), QTime(0, 0, 0)));
        lineEdit_date_d_2->setCurrentSection(QDateTimeEdit::DaySection);
        lineEdit_date_d_2->setCalendarPopup(true);
        lineEdit_date_d_2->setTimeSpec(Qt::LocalTime);
        lineEdit_date_d_2->setDate(QDate(2020, 4, 18));
        tabWidget_3->addTab(tab_9, QString());
        label_48->raise();
        lineEdit_id_4->raise();
        updatep->raise();
        lineEdit_nom_4->raise();
        lineEdit_duree_2->raise();
        lineEdit_prix_2->raise();
        label_38->raise();
        label_42->raise();
        label_43->raise();
        label_44->raise();
        label_52->raise();
        label_53->raise();
        lineEdit_date_f_2->raise();
        lineEdit_date_d_2->raise();
        tab_10 = new QWidget();
        tab_10->setObjectName(QStringLiteral("tab_10"));
        lineEdit_cin_2 = new QLineEdit(tab_10);
        lineEdit_cin_2->setObjectName(QStringLiteral("lineEdit_cin_2"));
        lineEdit_cin_2->setGeometry(QRect(290, 50, 113, 22));
        lineEdit_cin_2->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        searchp = new QPushButton(tab_10);
        searchp->setObjectName(QStringLiteral("searchp"));
        searchp->setGeometry(QRect(460, 70, 101, 21));
        searchp->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        label_50 = new QLabel(tab_10);
        label_50->setObjectName(QStringLiteral("label_50"));
        label_50->setGeometry(QRect(40, 20, 241, 20));
        label_50->setFont(font);
        label_50->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_51 = new QLabel(tab_10);
        label_51->setObjectName(QStringLiteral("label_51"));
        label_51->setGeometry(QRect(-10, 0, 761, 361));
        label_51->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        tabpub_2 = new QTableView(tab_10);
        tabpub_2->setObjectName(QStringLiteral("tabpub_2"));
        tabpub_2->setGeometry(QRect(10, 110, 551, 181));
        tabWidget_3->addTab(tab_10, QString());
        label_51->raise();
        searchp->raise();
        label_50->raise();
        lineEdit_cin_2->raise();
        tabpub_2->raise();
        tabWidget_2->addTab(tab_Ajouter, QString());
        tab_Afficher = new QWidget();
        tab_Afficher->setObjectName(QStringLiteral("tab_Afficher"));
        labelB_5 = new QLabel(tab_Afficher);
        labelB_5->setObjectName(QStringLiteral("labelB_5"));
        labelB_5->setGeometry(QRect(0, 0, 831, 571));
        labelB_5->setStyleSheet(QStringLiteral("background-color: rgb(170, 0, 0);"));
        tabWidget_4 = new QTabWidget(tab_Afficher);
        tabWidget_4->setObjectName(QStringLiteral("tabWidget_4"));
        tabWidget_4->setGeometry(QRect(70, 40, 521, 361));
        tabWidget_4->setFont(font1);
        tabWidget_4->setAutoFillBackground(false);
        tabWidget_4->setStyleSheet(QStringLiteral(""));
        tabWidget_4->setDocumentMode(true);
        tab_12 = new QWidget();
        tab_12->setObjectName(QStringLiteral("tab_12"));
        tabrev = new QTableView(tab_12);
        tabrev->setObjectName(QStringLiteral("tabrev"));
        tabrev->setGeometry(QRect(10, 40, 501, 261));
        label_57 = new QLabel(tab_12);
        label_57->setObjectName(QStringLiteral("label_57"));
        label_57->setGeometry(QRect(0, 0, 631, 441));
        label_57->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        label_57->setFrameShadow(QFrame::Plain);
        pdfr = new QPushButton(tab_12);
        pdfr->setObjectName(QStringLiteral("pdfr"));
        pdfr->setGeometry(QRect(440, 20, 75, 23));
        pdfr->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        searchr_2 = new QPushButton(tab_12);
        searchr_2->setObjectName(QStringLiteral("searchr_2"));
        searchr_2->setGeometry(QRect(480, 430, 93, 28));
        voir = new QPushButton(tab_12);
        voir->setObjectName(QStringLiteral("voir"));
        voir->setGeometry(QRect(10, 10, 131, 31));
        voir->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        tabWidget_4->addTab(tab_12, QString());
        label_57->raise();
        tabrev->raise();
        pdfr->raise();
        searchr_2->raise();
        voir->raise();
        tab_15 = new QWidget();
        tab_15->setObjectName(QStringLiteral("tab_15"));
        lineEdit_cin_3 = new QLineEdit(tab_15);
        lineEdit_cin_3->setObjectName(QStringLiteral("lineEdit_cin_3"));
        lineEdit_cin_3->setGeometry(QRect(330, 60, 113, 22));
        lineEdit_cin_3->setStyleSheet(QLatin1String("color: white;\n"
"background-color: rgb(89, 89, 89);\n"
"                                         border-radius: 10px;\n"
"                                         font: bold 14px;"));
        lineEdit_cin_3->setReadOnly(false);
        label_67 = new QLabel(tab_15);
        label_67->setObjectName(QStringLiteral("label_67"));
        label_67->setGeometry(QRect(40, 20, 361, 20));
        label_67->setFont(font);
        label_67->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_68 = new QLabel(tab_15);
        label_68->setObjectName(QStringLiteral("label_68"));
        label_68->setGeometry(QRect(0, -10, 761, 451));
        label_68->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        tabpub_4 = new QTableView(tab_15);
        tabpub_4->setObjectName(QStringLiteral("tabpub_4"));
        tabpub_4->setGeometry(QRect(40, 110, 431, 211));
        searchr = new QPushButton(tab_15);
        searchr->setObjectName(QStringLiteral("searchr"));
        searchr->setGeometry(QRect(410, 80, 101, 21));
        searchr->setStyleSheet(QLatin1String("border-color: rgb(170, 0, 0);\n"
"selection-color: rgb(170, 0, 0);\n"
"background-color: rgb(170, 0, 0);"));
        tabWidget_4->addTab(tab_15, QString());
        label_68->raise();
        lineEdit_cin_3->raise();
        label_67->raise();
        tabpub_4->raise();
        searchr->raise();
        tabWidget_2->addTab(tab_Afficher, QString());

        verticalLayout->addWidget(tabWidget_2);

#ifndef QT_NO_SHORTCUT
        label_41->setBuddy(label_41);
        label_42->setBuddy(lineEdit_nom_4);
        label_43->setBuddy(lineEdit_duree_2);
#endif // QT_NO_SHORTCUT

        retranslateUi(sponsor);

        tabWidget_2->setCurrentIndex(2);
        tabWidget->setCurrentIndex(3);
        pb_ajouter->setDefault(true);
        pdf->setDefault(true);
        voir_3->setDefault(true);
        ajouterr->setDefault(true);
        pb_supprimer->setDefault(true);
        update->setDefault(true);
        search->setDefault(true);
        tabWidget_3->setCurrentIndex(4);
        pb_ajouterp->setDefault(true);
        pdfp->setDefault(true);
        voir_2->setDefault(true);
        ajouterrr->setDefault(true);
        pb_supprimerp->setDefault(true);
        updatep->setDefault(true);
        searchp->setDefault(true);
        tabWidget_4->setCurrentIndex(1);
        pdfr->setDefault(true);
        searchr_2->setDefault(true);
        voir->setDefault(true);
        searchr->setDefault(true);


        QMetaObject::connectSlotsByName(sponsor);
    } // setupUi

    void retranslateUi(QDialog *sponsor)
    {
        sponsor->setWindowTitle(QApplication::translate("sponsor", "Dialog", nullptr));
        label_18->setText(QApplication::translate("sponsor", "ID Bus", nullptr));
        labelB_2->setText(QString());
        label->setText(QApplication::translate("sponsor", "Identifiant", nullptr));
        pb_ajouter->setText(QApplication::translate("sponsor", "Ajouter", nullptr));
        label_6->setText(QApplication::translate("sponsor", "le montant donn\303\251 (DT)", nullptr));
        label_7->setText(QApplication::translate("sponsor", "Nom  sponsor", nullptr));
        label_24->setText(QString());
        label_9->setText(QApplication::translate("sponsor", "<html><head/><body><p>date du dons</p></body></html>", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("sponsor", "Ajouter sponsor", nullptr));
#ifndef QT_NO_WHATSTHIS
        tabSPON->setWhatsThis(QApplication::translate("sponsor", "<html><head/><body><p>okkk<span style=\" color:#ff5500;\">jhg</span></p></body></html>", nullptr));
#endif // QT_NO_WHATSTHIS
        label_25->setText(QString());
        pdf->setText(QApplication::translate("sponsor", "Imprimer", nullptr));
        radioButton_6->setText(QApplication::translate("sponsor", "decroissant", nullptr));
        voir_3->setText(QApplication::translate("sponsor", "voir tout les sponsors", nullptr));
        label_47->setText(QApplication::translate("sponsor", "Ecrit  ID de sponsor  pour l'ajouter au revenu", nullptr));
        ajouterr->setText(QApplication::translate("sponsor", "Ajouter sponsor", nullptr));
        radioButton_5->setText(QApplication::translate("sponsor", "croissant", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("sponsor", "Afficher spons", nullptr));
        label_4->setText(QApplication::translate("sponsor", "Veuillez entrer l'identifiant de sponsor:", nullptr));
        pb_supprimer->setText(QApplication::translate("sponsor", "Supprimer", nullptr));
        label_23->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("sponsor", "Supprimer spons", nullptr));
        label_2->setText(QApplication::translate("sponsor", "Identifiant", nullptr));
        label_3->setText(QApplication::translate("sponsor", "Nom Sponsor", nullptr));
        label_5->setText(QApplication::translate("sponsor", "le montant donn\303\251 (DT)", nullptr));
        update->setText(QApplication::translate("sponsor", "Modifier", nullptr));
        label_22->setText(QString());
        label_10->setText(QApplication::translate("sponsor", "<html><head/><body><p>date du dons</p></body></html>", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_6), QApplication::translate("sponsor", "Modifier spons", nullptr));
        search->setText(QApplication::translate("sponsor", "Chercher", nullptr));
        label_8->setText(QApplication::translate("sponsor", "Veuillez entrer l'identifiant de sponsor :", nullptr));
        label_21->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_7), QApplication::translate("sponsor", "Chercher spons", nullptr));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_Supprimer), QApplication::translate("sponsor", "sponsor", nullptr));
        label_11->setText(QApplication::translate("sponsor", "Etat", nullptr));
        label_12->setText(QApplication::translate("sponsor", "Matricule", nullptr));
        label_13->setText(QApplication::translate("sponsor", "Nom chauffeur", nullptr));
        label_14->setText(QApplication::translate("sponsor", "Disponibilit\303\251", nullptr));
        label_15->setText(QApplication::translate("sponsor", "ID Bus", nullptr));
        label_16->setText(QApplication::translate("sponsor", "Marque", nullptr));
        label_17->setText(QApplication::translate("sponsor", "Capacit\303\251", nullptr));
        labelB_4->setText(QString());
        label_31->setText(QApplication::translate("sponsor", "num pub", nullptr));
        label_32->setText(QApplication::translate("sponsor", "date debut de pub", nullptr));
        label_33->setText(QApplication::translate("sponsor", "periode de  pub par min", nullptr));
        pb_ajouterp->setText(QApplication::translate("sponsor", "Ajouter", nullptr));
        label_34->setText(QApplication::translate("sponsor", "prix pub (DT)", nullptr));
        label_35->setText(QApplication::translate("sponsor", "nbr de repetition de pub par jr", nullptr));
        label_36->setText(QApplication::translate("sponsor", "nom pub", nullptr));
        label_37->setText(QString());
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_4), QApplication::translate("sponsor", "Ajouter pub", nullptr));
#ifndef QT_NO_WHATSTHIS
        tabpub->setWhatsThis(QApplication::translate("sponsor", "<html><head/><body><p>okkk<span style=\" color:#ff5500;\">jhg</span></p></body></html>", nullptr));
#endif // QT_NO_WHATSTHIS
        label_39->setText(QString());
        pdfp->setText(QApplication::translate("sponsor", "Imprimer", nullptr));
        radioButton_5p->setText(QApplication::translate("sponsor", "croissant", nullptr));
        radioButton_6p->setText(QApplication::translate("sponsor", "decroissant", nullptr));
        voir_2->setText(QApplication::translate("sponsor", "voir tt les pubs", nullptr));
        label_4r_2->setText(QApplication::translate("sponsor", "Ecrit l' ID  de PUB pour l'ajouter au revenu", nullptr));
        ajouterrr->setText(QApplication::translate("sponsor", "Ajouter pub", nullptr));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_5), QApplication::translate("sponsor", "Afficher les pub", nullptr));
        label_40->setText(QApplication::translate("sponsor", "Veuillez entrer le num de pub :", nullptr));
        pb_supprimerp->setText(QApplication::translate("sponsor", "Supprimer", nullptr));
        label_41->setText(QString());
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_8), QApplication::translate("sponsor", "Supprimer pub", nullptr));
        updatep->setText(QApplication::translate("sponsor", "Modifier", nullptr));
        label_48->setText(QString());
        label_38->setText(QApplication::translate("sponsor", "num pub", nullptr));
        label_42->setText(QApplication::translate("sponsor", "nom pub", nullptr));
        label_43->setText(QApplication::translate("sponsor", "nbr de repetition de pub par jr", nullptr));
        label_44->setText(QApplication::translate("sponsor", "date debut de pub", nullptr));
        label_52->setText(QApplication::translate("sponsor", "periode de pub (par min)", nullptr));
        label_53->setText(QApplication::translate("sponsor", "prix pub (DT)", nullptr));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_9), QApplication::translate("sponsor", "Modifier pub", nullptr));
        searchp->setText(QApplication::translate("sponsor", "Chercher", nullptr));
        label_50->setText(QApplication::translate("sponsor", "Veuillez entrer num de pub  :", nullptr));
        label_51->setText(QString());
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_10), QApplication::translate("sponsor", "Chercher pub", nullptr));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_Ajouter), QApplication::translate("sponsor", "pub", nullptr));
        labelB_5->setText(QString());
#ifndef QT_NO_WHATSTHIS
        tabrev->setWhatsThis(QApplication::translate("sponsor", "<html><head/><body><p>okkk<span style=\" color:#ff5500;\">jhg</span></p></body></html>", nullptr));
#endif // QT_NO_WHATSTHIS
        label_57->setText(QString());
        pdfr->setText(QApplication::translate("sponsor", "Imprimer", nullptr));
        searchr_2->setText(QApplication::translate("sponsor", "Chercher", nullptr));
        voir->setText(QApplication::translate("sponsor", "voir tout les revenus", nullptr));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_12), QApplication::translate("sponsor", "Afficher les revenus", nullptr));
        label_67->setText(QApplication::translate("sponsor", "Veuillez entrer le 1ere lettre du nom de pub ou de sponsor  :", nullptr));
        label_68->setText(QString());
        searchr->setText(QApplication::translate("sponsor", "Chercher", nullptr));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_15), QApplication::translate("sponsor", "Chercher revenu", nullptr));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_Afficher), QApplication::translate("sponsor", "revenus", nullptr));
    } // retranslateUi

};

namespace Ui {
    class sponsor: public Ui_sponsor {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SPONSOR_H
