#ifndef MAINWINDOWS_H
#define MAINWINDOWS_H

#include <QMainWindow>

namespace Ui {
class MainWindows;
}

class MainWindows : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindows(QWidget *parent = nullptr);
    ~MainWindows();

private:

};

#endif // MAINWINDOWS_H
