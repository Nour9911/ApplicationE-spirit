#ifndef TICKET_H
#define TICKET_H
#include <QString>
#include <QSqlQueryModel>
#include <QSqlQuery>

class ticket
{
public:
    ticket();
    ticket(QString,QString,QString);

    QString get_Id_res();
    QString get_Idt();
    QString get_tp();


    bool ajouter_ticket();
    QSqlQueryModel * afficher_ticket();
    bool supprimer_ticket(QString id);
    bool modifier_ticket(QString, QString, QString);
    bool chercher_ticket();
    QSqlQueryModel * afficher_Re_ticket(QString);
    QSqlQueryModel * afficher_tri_IDt();
    QSqlQueryModel * afficher_tri_IDt_DESC();
    QSqlQueryModel * refresh_Id_res();
    QSqlQueryModel * refresh_Idt();
    bool affecter_ticket(QString,QString);
    QSqlQueryModel * afficher_dyna_ticket(QString tic);


private:
    QString  Id_res ,Idt, tp;

};


#endif // TICKET_H
