#include "jee.h"
#include "ui_jee.h"
#include <QMessageBox>
#include "classentraineur.h"
#include "classequipe.h"
#include "classjoueur.h"
#include <QSqlQuery>
#include <QDebug>
#include <QVariant>
#include <QString>
#include <QPixmap>



jee::jee(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::jee)
{
    ui->setupUi(this);
    this->setWindowTitle("GESTION DES JOUEURS/EQUIPES/ENTRAINEURS");
    this->setWindowIcon(QIcon("../projetc/e-spirit.png"));
    QPixmap pix(":/new/prefix1/img/background.jpg");

    int w= ui->label_pic1->width();
    int h= ui->label_pic1->height();
    int w1= ui->label_pic2->width();
    int h1= ui->label_pic2->height();
    int w3= ui->label_pic4->width();
    int h3= ui->label_pic4->height();
    int w4= ui->label_pic5->width();
    int h4= ui->label_pic5->height();
    int w5= ui->label_pic6->width();
    int h5= ui->label_pic6->height();
    int w6= ui->label_pic7->width();
    int h6= ui->label_pic7->height();
    ui->label_pic1->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
    ui->label_pic2->setPixmap(pix.scaled(w1,h1,Qt::KeepAspectRatio));
      ui->label_pic4->setPixmap(pix.scaled(w3,h3,Qt::KeepAspectRatio));
            ui->label_pic5->setPixmap(pix.scaled(w4,h4,Qt::KeepAspectRatio));
            ui->label_pic6->setPixmap(pix.scaled(w5,h5,Qt::KeepAspectRatio));
            ui->label_pic7->setPixmap(pix.scaled(w6,h6,Qt::KeepAspectRatio));
    ui->table_joueur->setModel(tmpjoueur.afficher_joueur());
    ui->table_equipe->setModel(tmpequipe.afficher_equipe());
    ui->table_entraineur->setModel(tmpentraineur.afficher_entraineur());

  QSqlQuery query;
    query.prepare("select ID_EQUIPE from EQUIPE");
    if(query.exec())
        {
            while(query.next())
            {
                QString s = query.value(0).toString();//Récupère le résultat de la requête
                ui->combo_ID_equipe_2->addItem(s);
                ui->combo_ID_equipe->addItem(s);


            }
        }


    query.prepare("select ID_JOUEUR from JOUEUR");
    if(query.exec())
        {
            while(query.next())
            {
                QString m = query.value(0).toString();//Récupère le résultat de la requête
                ui->combo_ID_joueur->addItem(m);
            }
        }


    query.prepare("select ID_ENTRAINEUR from ENTRAINEUR");
    if(query.exec())
        {
            while(query.next())
            {
                QString E = query.value(0).toString();//Récupère le résultat de la requête
            ui->combo_ID_entraineur->addItem(E);
            }
        }
}

jee::~jee()
{
    delete ui;
}

void jee::on_Ajouter_joueur_clicked()
{
    bool verif_id,verif_nom,verif_prenom,verif_e,verif_en;

    bool verifID=false;
    bool verifNOM=false;
    bool verifPRENOM=false;
    bool verife=false;
     bool verifen=false;


    verif_id=true;
    verif_nom=true;
    verif_prenom=true;
    verif_e=true;
    verif_en=true;


    QString numbers = "0123456789";
    QString alphab = "azertyuiopqsdfghjklmwxcvbnéàçAZERTYUIOPQSDFGHJKLMWXCVBN";

    QString nom = ui->ajouter_nom_joueur->text();
    int v=0;
    for(int i = 0; i < nom.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(nom[i] == numbers[j]){
                          v = v +1;

                      }
                      if (v == 0)
                      verifNOM = true;
                      else if(v != 0)
                    verifNOM = false;
                  }
                  if(verifNOM == false ){
                      verif_nom = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur nom invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }



    QString id = ui->ajouter_id_joueur->text();
    for(int i = 0; i < id.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(id[i] == numbers[j]){
                          verifID = true;
                      }
                  }
                  if(verifID == false ){
                      verif_id = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur identifiant invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }

    QString prenom= ui->ajouter_prenom_joueur->text();
    for(int i = 0; i < prenom.length(); i++){
                  for(int j = 0; j < alphab.length(); j++){
                      if(prenom[i] == alphab[j]){
                          verifPRENOM = true;
                      }
                  }
                  if(verifPRENOM == false ){
                      verif_prenom = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur prenom invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }
    QString nom_equipe = ui->ajouter_nom_e_joueur->text();
    for(int i = 0; i < nom_equipe.length(); i++){
                  for(int j = 0; j < alphab.length(); j++){
                      if(nom_equipe[i] == alphab[j]){
                          verife = true;
                      }
                  }
                  if(verife == false ){
                      verif_e = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur nom equipe invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }
    QString  nom_entr = ui->ajouter_nom_en_joueur->text();
    for(int i = 0; i < nom_entr.length(); i++){
                  for(int j = 0; j < alphab.length(); j++){
                      if(nom_entr[i] == alphab[j]){
                          verifen = true;
                      }
                  }
                  if(verifen == false ){
                      verif_en = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur nom entraineur invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }
    if((verif_id == true)&&(verif_nom == true) && (verif_prenom == true)&&(verif_e == true)&&(verif_en == true)){
        classJoueur cl(id,nom,prenom,nom_equipe,nom_entr);
        bool test=cl.ajouter_joueur();

     if(test)
    {
        ui->combo_ID_joueur->setModel(tmpjoueur.refresh_id_joueur());
        ui->table_joueur->setModel(tmpjoueur.afficher_joueur());
        QMessageBox::information(nullptr, QObject::tr("Ajouter un joueur"),QObject::tr("Joueur ajoutee !!!.\n""Click cancel to exit."),QMessageBox::Cancel);
    }

}
}


/*QSqlQueryModel * classJoueur::afficher_joueur()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("SELECT * FROM JOUEUR");


    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Nom_equipe"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("Nom_entraineur"));


    return model;
}
*/

void jee::on_supprimer_joueur_clicked()
{
    QString id = ui->supprimer_joueur_2->text();
    bool test = tmpjoueur.supprimer_joueur(id);

    if(test)
    {
        ui->table_joueur->setModel(tmpjoueur.afficher_joueur());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un joueur"),
                        QObject::tr("joueur supprimé.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

        }
        else
            QMessageBox::critical(nullptr, QObject::tr("Supprimer un joueur"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);


    }






void jee::on_chercher_modif_joueur_clicked()
{

    QString id = ui->chercher_joueur->text();

        ui->table_Re_joueur->setModel(tmpjoueur.afficher_Re_joueur(id));//refresh

}


void jee::on_modifier_joueur_clicked()
{


        QString nom = ui->modifier_nom_joueur->text();
        QString id= ui->modifier_id_joueur->text();
        QString prenom = ui->modifier_prenom_joueur->text();
        QString nom_eq = ui->modifier_nom_e_joueur->text();
        QString nom_en = ui->modifier_nom_en_joueur_2->text();


    bool test=tmpjoueur.modifier_joueur(id,nom,prenom,nom_eq,nom_en);


    if (test)
      {
        ui->table_joueur->setModel(tmpjoueur.afficher_joueur());//refresh
        ui->table_Re_joueur->setModel(tmpjoueur.afficher_Re_joueur(id));//refresh

    QMessageBox::information(nullptr, QObject::tr("modifier un joueur"),
                    QObject::tr("joueur modifier.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("modifier un joueur"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}




/*void joueur::on_Statistique_joueur_clicked()
{
    QString val = ui->chercher_stat->text(),b1;
        float stat1=tmpstat.Calculer_Tab_Stat(val);  //pourcentage des bus de la marque val en panne
        float stat2=100-stat1;      //pourcentage des bus de la marque val en panne
        ui->chercher_stat_2->setText("Supp a 20 pts");
        ui->chercher_stat_4->setText("Inf a 20 pts");
        ui->chercher_stat_3->setText(b1.setNum(stat1));
        ui->chercher_stat_5->setText(b1.setNum(stat2));

}*/

void jee::on_tri_asc_clicked()
{
    ui->table_joueur->setModel(tmpjoueur.afficher_tri_ID());

}

void jee::on_tri_desc_clicked()
{
    ui->table_joueur->setModel(tmpjoueur.afficher_tri_ID_DESC());
}

void jee::on_tri_asc_2_clicked()
{
    ui->table_joueur->setModel(tmpjoueur.afficher_tri_NOM());

}
void jee::on_tri_desc_2_clicked()
{
    ui->table_joueur->setModel(tmpjoueur.afficher_tri_NOM_DESC());
}

void jee::on_Ajouter_equipe_clicked()
{
    bool verif_id,verif_nom,verif_en;

    bool verifID=false;
    bool verifNOM=false;

     bool verifen=false;


    verif_id=true;
    verif_nom=true;

    verif_en=true;


    QString numbers = "0123456789";
    QString alphab = "azertyuiopqsdfghjklmwxcvbnéàçAZERTYUIOPQSDFGHJKLMWXCVBN";

    QString nom = ui->ajouter_nom_equipe->text();
    for(int i = 0; i < nom.length(); i++){
                  for(int j = 0; j < alphab.length(); j++){
                      if(nom[i] == alphab[j]){
                          verifNOM = true;
                      }
                  }
                  if(verifNOM == false ){
                      verif_nom = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur nom invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }
    QString id = ui->ajouter_id_equipe->text();
    for(int i = 0; i < id.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(id[i] == numbers[j]){
                          verifID = true;
                      }
                  }
                  if(verifID == false ){
                      verif_id = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur identifiant invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }

    QString  nom_entr = ui->ajouter_nom_en_equipe->text();
    for(int i = 0; i < nom_entr.length(); i++){
                  for(int j = 0; j < alphab.length(); j++){
                      if(nom_entr[i] == alphab[j]){
                          verifen = true;
                      }
                  }
                  if(verifen == false ){
                      verif_en = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur nom entraineur invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }

    if((verif_id == true)&&(verif_nom == true) && (verif_en == true)){
        classEquipe cl(id,nom,nom_entr);
        bool test=cl.ajouter_equipe();

        if(test)
        {
            ui->combo_ID_equipe->setModel(tmpequipe.refresh_id_equipe());
            ui->combo_ID_equipe_2->setModel(tmpequipe.refresh_id_equipe());
            ui->table_equipe->setModel(tmpequipe.afficher_equipe());
            QMessageBox::information(nullptr, QObject::tr("Ajouter une equipe"),QObject::tr("equipe ajoutee !!!.\n""Click cancel to exit."),QMessageBox::Cancel);
        }

}


}


/*QSqlQueryModel * classEquipe::afficher_equipe()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("SELECT * FROM EQUIPE");

    model->setHeaderData(0, Qt::Horizontal, QObject::tr("NOM_EQUIPE"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("ID_EQUIPE"));


    model->setHeaderData(2, Qt::Horizontal, QObject::tr("ENTRAINEUR_EQUI"));



    return model;
}
*/

void jee::on_supprimer_equipe_clicked()
{
    QString id = ui->supprimer_equipe_2->text();
    bool test = tmpequipe.supprimer_equipe(id);

    if(test)
    {
        ui->table_equipe->setModel(tmpequipe.afficher_equipe());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer une equipe"),
                        QObject::tr("equipe supprimé.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

        }
        else
            QMessageBox::critical(nullptr, QObject::tr("Supprimer un equipe"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);


    }






void jee::on_chercher_modif_equipe_clicked()
{

    QString id = ui->chercher_equipe->text();

        ui->table_Re_equipe->setModel(tmpequipe.afficher_Re_equipe(id));//refresh

}


void jee::on_modifier_equipe_clicked()
{


        QString nom = ui->modifier_nom_equipe->text();
        QString id= ui->modifier_id_equipe->text();

        QString nom_en = ui->modifier_nom_en_equipe->text();


    bool test=tmpequipe.modifier_equipe(id,nom,nom_en);


    if (test)
      {
        ui->table_equipe->setModel(tmpequipe.afficher_equipe());//refresh
        ui->table_Re_equipe->setModel(tmpequipe.afficher_Re_equipe(id));//refresh

    QMessageBox::information(nullptr, QObject::tr("modifier une equipe"),
                    QObject::tr("equipe modifier.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("modifier une equipe"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}




/*void joueur::on_Statistique_joueur_clicked()
{
    QString val = ui->chercher_stat->text(),b1;
        float stat1=tmpstat.Calculer_Tab_Stat(val);  //pourcentage des bus de la marque val en panne
        float stat2=100-stat1;      //pourcentage des bus de la marque val en panne
        ui->chercher_stat_2->setText("Supp a 20 pts");
        ui->chercher_stat_4->setText("Inf a 20 pts");
        ui->chercher_stat_3->setText(b1.setNum(stat1));
        ui->chercher_stat_5->setText(b1.setNum(stat2));

}*/

void jee::on_tri_asce_clicked()
{
    ui->table_equipe->setModel(tmpequipe.afficher_tri_ID());

}

void jee::on_tri_desce_clicked()
{
    ui->table_equipe->setModel(tmpequipe.afficher_tri_ID_DESC());
}

void jee::on_tri_asce_2_clicked()
{
    ui->table_equipe->setModel(tmpequipe.afficher_tri_NOM());

}
void jee::on_tri_desce_2_clicked()
{
    ui->table_equipe->setModel(tmpequipe.afficher_tri_NOM_DESC());
}
void jee::on_Ajouter_entraineur_clicked()
{
    bool verif_id,verif_nom,verif_prenom,verif_e;

    bool verifID=false;
    bool verifNOM=false;
    bool verifPRENOM=false;
    bool verife=false;



    verif_id=true;
    verif_nom=true;
    verif_prenom=true;
    verif_e=true;


    QString numbers = "0123456789";
    QString alphab = "azertyuiopqsdfghjklmwxcvbnéàçAZERTYUIOPQSDFGHJKLMWXCVBN";
    QString nom = ui->ajouter_nom_entraineur->text();
    for(int i = 0; i < nom.length(); i++){
                  for(int j = 0; j < alphab.length(); j++){
                      if(nom[i] == alphab[j]){
                          verifNOM = true;
                      }
                  }
                  if(verifNOM == false ){
                      verif_nom = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur nom invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }
    QString id = ui->ajouter_id_entraineur->text();
    for(int i = 0; i < id.length(); i++){
                  for(int j = 0; j < numbers.length(); j++){
                      if(id[i] == numbers[j]){
                          verifID = true;
                      }
                  }
                  if(verifID == false ){
                      verif_id = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur identifiant invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }

    QString prenom=ui->ajouter_prenom_entraineur->text();
    for(int i = 0; i < prenom.length(); i++){
                  for(int j = 0; j < alphab.length(); j++){
                      if(prenom[i] == alphab[j]){
                          verifPRENOM = true;
                      }
                  }
                  if(verifPRENOM == false ){
                      verif_prenom = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur prenom invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }

    QString  nom_equipe = ui->ajouter_nom_entraineur_2->text();
    for(int i = 0; i < nom_equipe.length(); i++){
                  for(int j = 0; j < alphab.length(); j++){
                      if(nom_equipe[i] == alphab[j]){
                          verife = true;
                      }
                  }
                  if(verife == false ){
                      verif_e = false;
                      QMessageBox::information(nullptr, QObject::tr("Erreur"),
                                  QObject::tr("Erreur nom equipe invalide .\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                      break;
                  }
              }
    if((verif_id == true)&&(verif_nom == true) && (verif_prenom == true)&&(verif_e == true)){
        classEntraineur cl(id,nom,prenom,nom_equipe);
        bool test=cl.ajouter_entraineur();

        if(test)
        {
            ui->combo_ID_entraineur->setModel(tmpentraineur.refresh_id_entraineur());
            ui->table_entraineur->setModel(tmpentraineur.afficher_entraineur());
            QMessageBox::information(nullptr, QObject::tr("Ajouter une entraineur"),QObject::tr("entraineur ajoutee !!!.\n""Click cancel to exit."),QMessageBox::Cancel);
        }


}


}


/*QSqlQueryModel * classEquipe::afficher_equipe()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("SELECT * FROM EQUIPE");

    model->setHeaderData(0, Qt::Horizontal, QObject::tr("NOM_EQUIPE"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("ID_EQUIPE"));


    model->setHeaderData(2, Qt::Horizontal, QObject::tr("ENTRAINEUR_EQUI"));



    return model;
}
*/

void jee::on_supprimer_entraineur_clicked()
{
    QString id = ui->supprimer_entraineur_2->text();
    bool test = tmpentraineur.supprimer_entraineur(id);

    if(test)
    {
        ui->table_entraineur->setModel(tmpentraineur.afficher_entraineur());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un entraineur"),
                        QObject::tr("entraineur supprimé.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

        }
        else
            QMessageBox::critical(nullptr, QObject::tr("Supprimer un entraineur"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);


    }






void jee::on_chercher_modif_entraineur_clicked()
{

    QString id = ui->chercher_entraineur->text();

        ui->table_Re_entraineur->setModel(tmpentraineur.afficher_Re_entraineur(id));//refresh

}


void jee::on_modifier_entraineur_clicked()
{


        QString nom = ui->modifier_nom_entraineur->text();
        QString id= ui->modifier_id_entraineur->text();
        QString prenom= ui->modifier_prenom_entraineur->text();
         QString nom_equipe = ui->modifier_nom_e_entraineur->text();


    bool test=tmpentraineur.modifier_entraineur(id,nom,prenom,nom_equipe);


    if (test)
      {
        ui->table_entraineur->setModel(tmpentraineur.afficher_entraineur());//refresh
        ui->table_Re_entraineur->setModel(tmpentraineur.afficher_Re_entraineur(id));//refresh

    QMessageBox::information(nullptr, QObject::tr("modifier un entraineur"),
                    QObject::tr("entraineur modifier.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("modifier un entraineur"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}





void jee::on_tri_ascen_clicked()
{
    ui->table_entraineur->setModel(tmpentraineur.afficher_tri_ID());

}

void jee::on_tri_descen_clicked()
{
    ui->table_entraineur->setModel(tmpentraineur.afficher_tri_ID_DESC());
}


void jee::on_tri_ascen_2_clicked()
{
    ui->table_entraineur->setModel(tmpentraineur.afficher_tri_NOM());

}
void jee::on_tri_descen_2_clicked()
{
    ui->table_entraineur->setModel(tmpentraineur.afficher_tri_NOM_DESC());
}

 void jee::on_affecter_en_eq_clicked()
{
     QString id_entraineur = ui->combo_ID_entraineur->currentText();
     QString id_equipe = ui->combo_ID_equipe->currentText();


     bool test=tmpentraineur.affecter_entraineur(id_entraineur,id_equipe);

     if(test)
     {
         ui->table_entraineur->setModel(tmpentraineur.afficher_entraineur());
         QMessageBox::information(nullptr, QObject::tr("Affecter un entraineur"),QObject::tr("entraineur affecter.\n""Click cancel to exit."),QMessageBox::Cancel);
     }

 else
     QMessageBox::critical(nullptr, QObject::tr("Affecter un entraineur"),
                 QObject::tr("Erreur !.\n"
                             "Click Cancel to exit."), QMessageBox::Cancel);
}
 void jee::on_affecter_j_eq_clicked()
{
     QString id_joueur = ui->combo_ID_joueur->currentText();
     QString id_equipe = ui->combo_ID_equipe_2->currentText();


     bool test=tmpjoueur.affecter_joueur(id_joueur,id_equipe);

     if(test)
     {
         ui->table_joueur->setModel(tmpjoueur.afficher_joueur());
         QMessageBox::information(nullptr, QObject::tr("Affecter un joueur"),QObject::tr("joueur affecter.\n""Click cancel to exit."),QMessageBox::Cancel);
     }

 else
     QMessageBox::critical(nullptr, QObject::tr("Affecter un joueur"),
                 QObject::tr("Erreur !.\n"
                             "Click Cancel to exit."), QMessageBox::Cancel);
}



void jee::on_chercher_joueur_textChanged(const QString &arg1)
{
    ui->table_Re_joueur->setModel(tmpjoueur.afficher_dyna_joueur(arg1));//refresh

}

void jee::on_chercher_entraineur_textChanged(const QString &arg1)
{
    ui->table_Re_entraineur->setModel(tmpentraineur.afficher_dyna_entraineur(arg1));//refresh
}

void jee::on_chercher_equipe_textChanged(const QString &arg1)
{
   ui->table_Re_equipe->setModel(tmpequipe.afficher_dyna_equipe(arg1));//refresh
}
