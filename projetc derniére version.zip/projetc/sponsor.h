#ifndef SPONSOR_H
#define SPONSOR_H
#include <classpub.h>
#include <QDialog>
#include <classspons.h>
#include <QDate>
#include <classrev.h>
#include <QApplication>
#include <QtWidgets/QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QHorizontalStackedBarSeries>
#include <QtCharts/QLineSeries>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>

namespace Ui {
class sponsor;
}

class sponsor : public QDialog
{
    Q_OBJECT

public:
    explicit sponsor(QWidget *parent = nullptr);
    ~sponsor();

private slots:
        void on_pb_ajouter_clicked();
        void on_pb_supprimer_clicked();
        void on_update_clicked();
        void on_search_clicked();
         void on_pdf_clicked();
        void on_radioButton_5_clicked();
        void on_radioButton_6_clicked();
        void on_voir_3_clicked();


             void on_pb_ajouterp_clicked();
             void on_pb_supprimerp_clicked();
             void on_updatep_clicked();
             void on_searchp_clicked();
             void on_pdfp_clicked();
             void on_radioButton_5p_clicked();
             void on_radioButton_6p_clicked();

             void on_voir_2_clicked();

             void on_ajouterr_clicked();
             void on_ajouterrr_clicked();
             void on_searchr_clicked();
             void on_voir_clicked();
             void on_pdfr_clicked();
             void on_radioButton_5r_clicked();
             void on_radioButton_6r_clicked();




  void on_lineEdit_cin_3_selectionChanged();



private:
    Ui::sponsor *ui;
    classspons tmpSPON;
    classpub tmppub;
    classrev tmprev;

};

#endif // SPONSOR_H
