#include "mainwindow.h"
#include <QSqlDatabase>
#include <QSql>
#include <QDebug>
#include <QApplication>
#include <connexion.h>
#include <login.h>
#include <classrev.h>
#include <classrev.h>
#include <QMessageBox>
#include <QtWidgets/QMainWindow>

//statistique
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QHorizontalStackedBarSeries>
#include <QtCharts/QLineSeries>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    Connection c;
    classrev r ;
    login l ;


bool test=c.createconnect();
if(test)
{w.show();

} else {}






return a.exec();}



