#ifndef STATISTIQUE_H
#define STATISTIQUE_H

#include <QWidget>

class statistique : public QWidget
{
    Q_OBJECT
public:
    explicit statistique(QWidget *parent = nullptr);
protected:
    void paintEvent (QPaintEvent *);


signals:

public slots:
};

#endif // STATISTIQUE_H
